"""SNT Monolit Backend Application"""
