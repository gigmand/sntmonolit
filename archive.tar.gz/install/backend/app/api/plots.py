"""
Plots API endpoints
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import Optional, List

from app.db.database import get_db
from app.api.auth import get_current_user
from app.services import PlotService, MemberService, OwnershipHistoryService
from app.schemas import (
    PlotCreate, PlotUpdate, PlotResponse, PlotListItem, PlotDetail,
    OwnershipHistoryCreate, OwnershipHistoryItem,
    UserResponse, PlotStatusEnum
)
from app.models import Plot, MemberPlot

router = APIRouter(prefix="/plots", tags=["Plots"])


@router.get("", response_model=List[PlotListItem])
def get_plots(
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    search: Optional[str] = None,
    status: Optional[PlotStatusEnum] = None,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Get all plots with filtering and pagination."""
    plots, total = PlotService.get_all(
        db, skip=skip, limit=limit, search=search, status=status
    )
    
    # Enrich with member names
    result = []
    for plot in plots:
        member_names = [mp.member.full_name for mp in plot.members]
        
        item = PlotListItem(
            id=plot.id,
            plot_number=plot.plot_number,
            alley=plot.alley,
            cadastral_number=plot.cadastral_number,
            area=float(plot.area),
            status=plot.status,
            member_names=member_names,
            created_at=plot.created_at
        )
        result.append(item)
    
    return result


@router.get("/{plot_id}", response_model=PlotDetail)
def get_plot(
    plot_id: int,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Get plot by ID."""
    plot = PlotService.get_by_id(db, plot_id)
    if not plot:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plot not found"
        )
    
    # Get members
    members = []
    for mp in plot.members:
        members.append({
            "id": mp.member.id,
            "full_name": mp.member.full_name,
            "ownership_share": float(mp.ownership_share)
        })
    
    # Get ownership history
    history = []
    for h in plot.ownership_history:
        history.append({
            "id": h.id,
            "member_id": h.member_id,
            "plot_id": h.plot_id,
            "transfer_date": h.transfer_date,
            "transfer_type": h.transfer_type.value,
            "document_number": h.document_number,
            "comment": h.comment,
            "member_name": h.member.full_name,
            "plot_number": plot.plot_number,
            "created_at": h.created_at
        })
    
    return PlotDetail(
        id=plot.id,
        plot_number=plot.plot_number,
        alley=plot.alley,
        cadastral_number=plot.cadastral_number,
        area=float(plot.area),
        status=plot.status,
        created_at=plot.created_at,
        updated_at=plot.updated_at,
        members=members,
        ownership_history=history
    )


@router.post("", response_model=PlotResponse, status_code=status.HTTP_201_CREATED)
def create_plot(
    plot: PlotCreate,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Create a new plot."""
    # Validate member IDs if provided
    if plot.member_ids:
        for member_id in plot.member_ids:
            member = MemberService.get_by_id(db, member_id)
            if not member:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Member with ID {member_id} not found"
                )
    
    # Check if plot number already exists
    existing = db.query(Plot).filter(Plot.plot_number == plot.plot_number).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Plot with this number already exists"
        )
    
    return PlotService.create(db, plot)


@router.put("/{plot_id}", response_model=PlotResponse)
def update_plot(
    plot_id: int,
    plot_update: PlotUpdate,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Update a plot."""
    plot = PlotService.get_by_id(db, plot_id)
    if not plot:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plot not found"
        )
    
    # Validate member IDs if provided
    if plot_update.member_ids:
        for member_id in plot_update.member_ids:
            member = MemberService.get_by_id(db, member_id)
            if not member:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Member with ID {member_id} not found"
                )
    
    return PlotService.update(db, plot, plot_update)


@router.delete("/{plot_id}")
def delete_plot(
    plot_id: int,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Delete a plot."""
    plot = PlotService.get_by_id(db, plot_id)
    if not plot:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plot not found"
        )
    
    PlotService.delete(db, plot)
    return {"message": "Plot deleted successfully"}


@router.get("/{plot_id}/history", response_model=List[OwnershipHistoryItem])
def get_plot_history(
    plot_id: int,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Get ownership history for a plot."""
    plot = PlotService.get_by_id(db, plot_id)
    if not plot:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plot not found"
        )
    
    history = OwnershipHistoryService.get_by_plot(db, plot_id)
    
    result = []
    for h in history:
        result.append({
            "id": h.id,
            "member_id": h.member_id,
            "plot_id": h.plot_id,
            "transfer_date": h.transfer_date,
            "transfer_type": h.transfer_type.value,
            "document_number": h.document_number,
            "comment": h.comment,
            "member_name": h.member.full_name,
            "plot_number": plot.plot_number,
            "created_at": h.created_at
        })
    
    return result


@router.post("/{plot_id}/history", response_model=OwnershipHistoryItem, status_code=status.HTTP_201_CREATED)
def add_plot_history(
    plot_id: int,
    history: OwnershipHistoryCreate,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Add ownership history entry for a plot."""
    plot = PlotService.get_by_id(db, plot_id)
    if not plot:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plot not found"
        )
    
    member = MemberService.get_by_id(db, history.member_id)
    if not member:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Member not found"
        )
    
    db_history = OwnershipHistoryService.create(db, history)
    
    return {
        "id": db_history.id,
        "member_id": db_history.member_id,
        "plot_id": db_history.plot_id,
        "transfer_date": db_history.transfer_date,
        "transfer_type": db_history.transfer_type.value,
        "document_number": db_history.document_number,
        "comment": db_history.comment,
        "member_name": member.full_name,
        "plot_number": plot.plot_number,
        "created_at": db_history.created_at
    }
