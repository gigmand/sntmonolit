import React, { useEffect, useState } from 'react';
import {
  Table, Button, Space, Input, Select, Tag, Modal, Form,
  message, Popconfirm, Drawer, Descriptions, InputNumber,
} from 'antd';
import type { ColumnsType } from 'antd/es/table';
import {
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  EyeOutlined,
  SearchOutlined,
  HistoryOutlined,
} from '@ant-design/icons';
import { plotsApi, membersApi } from '@/services/api';
import type { Plot, PlotListItem, PlotStatus, MemberListItem } from '@/types/api';

const { Search } = Input;

const Plots: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [plots, setPlots] = useState<PlotListItem[]>([]);
  const [selectedPlot, setSelectedPlot] = useState<any>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [historyDrawerOpen, setHistoryDrawerOpen] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingPlot, setEditingPlot] = useState<Plot | null>(null);
  const [form] = Form.useForm();
  const [searchText, setSearchText] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [allMembers, setAllMembers] = useState<MemberListItem[]>([]);

  useEffect(() => {
    loadPlots();
    loadMembers();
  }, [statusFilter]);

  const loadPlots = async () => {
    try {
      setLoading(true);
      const params: Record<string, any> = { limit: 100 };
      if (searchText) params.search = searchText;
      if (statusFilter) params.status = statusFilter;
      
      const data = await plotsApi.getAll(params);
      setPlots(data);
    } catch (error) {
      message.error('Ошибка загрузки участков');
    } finally {
      setLoading(false);
    }
  };

  const loadMembers = async () => {
    try {
      const data = await membersApi.getAll({ limit: 100 });
      setAllMembers(data);
    } catch (error) {
      console.error('Failed to load members:', error);
    }
  };

  const handleSearch = (value: string) => {
    setSearchText(value);
    setTimeout(loadPlots, 500);
  };

  const handleView = async (id: number) => {
    try {
      const plot = await plotsApi.getById(id);
      setSelectedPlot(plot);
      setDrawerOpen(true);
    } catch (error) {
      message.error('Ошибка загрузки данных');
    }
  };

  const handleViewHistory = async (id: number) => {
    try {
      const plot = await plotsApi.getById(id);
      setSelectedPlot(plot);
      setHistoryDrawerOpen(true);
    } catch (error) {
      message.error('Ошибка загрузки истории');
    }
  };

  const handleEdit = (plot: PlotListItem) => {
    setEditingPlot(plot);
    // Find member IDs by names
    const memberIds = plot.member_names
      .map(name => {
        const member = allMembers.find(m => m.full_name === name);
        return member ? member.id : null;
      })
      .filter((id): id is number => id !== null);
    
    form.setFieldsValue({
      ...plot,
      member_ids: memberIds,
    });
    setModalOpen(true);
  };

  const handleCreate = () => {
    setEditingPlot(null);
    form.resetFields();
    setModalOpen(true);
  };

  const handleSave = async () => {
    try {
      const values = await form.validateFields();
      const plotData = {
        ...values,
      };

      if (editingPlot) {
        await plotsApi.update(editingPlot.id, plotData);
        message.success('Участок обновлен');
      } else {
        await plotsApi.create(plotData);
        message.success('Участок создан');
      }
      
      setModalOpen(false);
      loadPlots();
    } catch (error: any) {
      if (error?.response?.data?.detail) {
        message.error(error.response.data.detail);
      }
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await plotsApi.delete(id);
      message.success('Участок удален');
      loadPlots();
    } catch (error) {
      message.error('Ошибка удаления');
    }
  };

  const getStatusColor = (status: PlotStatus) => {
    const colorMap: Record<PlotStatus, string> = {
      active: 'green',
      inactive: 'orange',
      archived: 'gray',
    };
    return colorMap[status];
  };

  const getStatusLabel = (status: PlotStatus) => {
    const labelMap: Record<PlotStatus, string> = {
      active: 'Активный',
      inactive: 'Неактивный',
      archived: 'Архив',
    };
    return labelMap[status];
  };

  const columns: ColumnsType<PlotListItem> = [
    {
      title: 'Номер',
      dataIndex: 'plot_number',
      key: 'plot_number',
      sorter: (a, b) => a.plot_number.localeCompare(b.plot_number),
    },
    {
      title: 'Аллея',
      dataIndex: 'alley',
      key: 'alley',
    },
    {
      title: 'Кадастровый №',
      dataIndex: 'cadastral_number',
      key: 'cadastral_number',
    },
    {
      title: 'Площадь',
      dataIndex: 'area',
      key: 'area',
      render: (value: number) => `${value} сот.`,
      sorter: (a, b) => a.area - b.area,
    },
    {
      title: 'Владельцы',
      dataIndex: 'member_names',
      key: 'member_names',
      render: (names: string[]) => names.join(', ') || '—',
    },
    {
      title: 'Статус',
      dataIndex: 'status',
      key: 'status',
      render: (status: PlotStatus) => (
        <Tag color={getStatusColor(status)}>{getStatusLabel(status)}</Tag>
      ),
      filters: [
        { text: 'Активный', value: 'active' },
        { text: 'Неактивный', value: 'inactive' },
        { text: 'Архив', value: 'archived' },
      ],
      onFilter: (value, record) => record.status === value,
    },
    {
      title: 'Действия',
      key: 'actions',
      render: (_, record) => (
        <Space>
          <Button
            type="link"
            icon={<EyeOutlined />}
            onClick={() => handleView(record.id)}
          />
          <Button
            type="link"
            icon={<HistoryOutlined />}
            onClick={() => handleViewHistory(record.id)}
          />
          <Button
            type="link"
            icon={<EditOutlined />}
            onClick={() => handleEdit(record)}
          />
          <Popconfirm
            title="Удалить участок?"
            onConfirm={() => handleDelete(record.id)}
            okText="Да"
            cancelText="Отмена"
          >
            <Button type="link" danger icon={<DeleteOutlined />} />
          </Popconfirm>
        </Space>
      ),
    },
  ];

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
        <Space>
          <Search
            placeholder="Поиск по номеру, аллее, кадастровому номеру"
            allowClear
            onSearch={handleSearch}
            style={{ width: 350 }}
          />
          <Select
            placeholder="Статус"
            allowClear
            style={{ width: 150 }}
            onChange={setStatusFilter}
            options={[
              { value: 'active', label: 'Активный' },
              { value: 'inactive', label: 'Неактивный' },
              { value: 'archived', label: 'Архив' },
            ]}
          />
        </Space>
        <Button type="primary" icon={<PlusOutlined />} onClick={handleCreate}>
          Добавить участок
        </Button>
      </div>

      <Table
        columns={columns}
        dataSource={plots}
        rowKey="id"
        loading={loading}
        scroll={{ x: 1000 }}
      />

      {/* View Drawer */}
      <Drawer
        title="Информация об участке"
        placement="right"
        width={600}
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
      >
        {selectedPlot && (
          <Descriptions column={1} bordered>
            <Descriptions.Item label="Номер участка">{selectedPlot.plot_number}</Descriptions.Item>
            <Descriptions.Item label="Аллея">{selectedPlot.alley || '—'}</Descriptions.Item>
            <Descriptions.Item label="Кадастровый номер">{selectedPlot.cadastral_number || '—'}</Descriptions.Item>
            <Descriptions.Item label="Площадь">{selectedPlot.area} сот.</Descriptions.Item>
            <Descriptions.Item label="Статус">
              <Tag color={getStatusColor(selectedPlot.status)}>
                {getStatusLabel(selectedPlot.status)}
              </Tag>
            </Descriptions.Item>
            <Descriptions.Item label="Владельцы">
              {selectedPlot.members?.length > 0 ? (
                <ul>
                  {selectedPlot.members.map((m: any) => (
                    <li key={m.id}>
                      {m.full_name} ({m.ownership_share}%)
                    </li>
                  ))}
                </ul>
              ) : '—'}
            </Descriptions.Item>
            <Descriptions.Item label="История владения">
              {selectedPlot.ownership_history?.length > 0 ? (
                `${selectedPlot.ownership_history.length} записей`
              ) : '—'}
            </Descriptions.Item>
          </Descriptions>
        )}
      </Drawer>

      {/* History Drawer */}
      <Drawer
        title="История владения участком"
        placement="right"
        width={600}
        open={historyDrawerOpen}
        onClose={() => setHistoryDrawerOpen(false)}
      >
        {selectedPlot?.ownership_history && selectedPlot.ownership_history.length > 0 ? (
          <Table
            columns={[
              {
                title: 'Дата',
                dataIndex: 'transfer_date',
                key: 'transfer_date',
                render: (date: string) => new Date(date).toLocaleDateString('ru-RU'),
              },
              {
                title: 'Владелец',
                dataIndex: 'member_name',
                key: 'member_name',
              },
              {
                title: 'Тип',
                dataIndex: 'transfer_type',
                key: 'transfer_type',
                render: (type: string) => {
                  const labels: Record<string, string> = {
                    sale: 'Продажа',
                    inheritance: 'Наследование',
                    gift: 'Дарение',
                    other: 'Иное',
                  };
                  return labels[type] || type;
                },
              },
              {
                title: 'Документ',
                dataIndex: 'document_number',
                key: 'document_number',
                render: (doc: string) => doc || '—',
              },
              {
                title: 'Комментарий',
                dataIndex: 'comment',
                key: 'comment',
                render: (comment: string) => comment || '—',
              },
            ]}
            dataSource={selectedPlot.ownership_history}
            rowKey="id"
            pagination={false}
          />
        ) : (
          <p>История владения отсутствует</p>
        )}
      </Drawer>

      {/* Edit/Create Modal */}
      <Modal
        title={editingPlot ? 'Редактировать участок' : 'Новый участок'}
        open={modalOpen}
        onOk={handleSave}
        onCancel={() => setModalOpen(false)}
        width={600}
      >
        <Form form={form} layout="vertical">
          <Form.Item name="plot_number" label="Номер участка" rules={[{ required: true }]}>
            <Input />
          </Form.Item>
          <Form.Item name="alley" label="Аллея">
            <Input />
          </Form.Item>
          <Form.Item name="cadastral_number" label="Кадастровый номер">
            <Input />
          </Form.Item>
          <Form.Item name="area" label="Площадь (сот.)" rules={[{ required: true }]}>
            <InputNumber style={{ width: '100%' }} min={0} step={0.01} />
          </Form.Item>
          <Form.Item name="status" label="Статус">
            <Select>
              <Select.Option value="active">Активный</Select.Option>
              <Select.Option value="inactive">Неактивный</Select.Option>
              <Select.Option value="archived">Архив</Select.Option>
            </Select>
          </Form.Item>
          <Form.Item 
            name="member_ids" 
            label="Владельцы (члены СНТ)"
            tooltip="Можно выбрать несколько владельцев"
          >
            <Select
              mode="multiple"
              placeholder="Выберите владельцев"
              options={allMembers.map(m => ({
                value: m.id,
                label: m.full_name,
              }))}
              showSearch
              filterOption={(input, option) =>
                (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
              }
              style={{ width: '100%' }}
            />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default Plots;
