"""
Database models for SNT Monolit
"""
from datetime import datetime
import sqlalchemy
from sqlalchemy import (
    Column, Integer, String, Float, DateTime, Boolean, ForeignKey,
    Text, Date, Enum as SQLEnum, DECIMAL
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.database import Base
import enum


class UserRole(str, enum.Enum):
    """User roles for access control."""
    ADMIN = "admin"
    CHAIRMAN = "chairman"
    TREASURER = "treasurer"
    SECRETARY = "secretary"
    OBSERVER = "observer"


class MemberStatus(str, enum.Enum):
    """Member status types."""
    ACTIVE = "active"
    DEBTOR = "debtor"
    FORMER = "former"
    DECEASED = "deceased"


class PlotStatus(str, enum.Enum):
    """Plot status types."""
    ACTIVE = "active"
    INACTIVE = "inactive"
    ARCHIVED = "archived"


class OwnershipType(str, enum.Enum):
    """Ownership transfer types."""
    SALE = "sale"
    INHERITANCE = "inheritance"
    GIFT = "gift"
    OTHER = "other"


class FeeType(str, enum.Enum):
    """Fee types."""
    MEMBER = "member"
    TARGET = "target"
    ELECTRICITY = "electricity"


class PaymentMethod(str, enum.Enum):
    """Payment methods."""
    CASH = "cash"
    BANK_TRANSFER = "bank_transfer"
    CARD = "card"


class DebtCategory(str, enum.Enum):
    """Debt amount categories."""
    SMALL = "small"  # < 1000
    MEDIUM = "medium"  # 1000-5000
    LARGE = "large"  # > 5000


# ============================================
# Users (системные пользователи)
# ============================================
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    email = Column(String(100), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(200), nullable=False)
    role = Column(SQLEnum(UserRole), default=UserRole.OBSERVER)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    # Relationships
    action_logs = relationship("ActionLog", back_populates="user")


# ============================================
# Members (члены СНТ)
# ============================================
class Member(Base):
    __tablename__ = "members"

    id = Column(Integer, primary_key=True, index=True)
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    middle_name = Column(String(100))
    birth_date = Column(Date)
    phone = Column(String(50))
    email = Column(String(100))
    address = Column(String(255))
    membership_start_date = Column(Date)
    membership_end_date = Column(Date)
    status = Column(SQLEnum(MemberStatus), default=MemberStatus.ACTIVE)
    status_comment = Column(Text)
    has_irrigation = Column(Boolean, default=False)  # Есть ли полив на участке
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    # Relationships
    plots = relationship("MemberPlot", back_populates="member", cascade="all, delete-orphan")
    ownership_history = relationship("OwnershipHistory", back_populates="member", cascade="all, delete-orphan")
    accruals = relationship("FeeAccrual", back_populates="member", cascade="all, delete-orphan")
    payments = relationship("FeePayment", back_populates="member", cascade="all, delete-orphan")
    debts = relationship("MemberDebt", back_populates="member", cascade="all, delete-orphan")

    @property
    def full_name(self) -> str:
        parts = [self.last_name, self.first_name, self.middle_name or ""]
        return " ".join(p for p in parts if p)

    @property
    def has_debt(self) -> bool:
        return self.status == MemberStatus.DEBTOR


# ============================================
# Plots (участки)
# ============================================
class Plot(Base):
    __tablename__ = "plots"

    id = Column(Integer, primary_key=True, index=True)
    plot_number = Column(String(20), unique=True, nullable=False)
    alley = Column(String(100))
    cadastral_number = Column(String(50), unique=True)
    area = Column(DECIMAL(10, 2), nullable=False)  # in sotkas (hundredths of hectare)
    status = Column(SQLEnum(PlotStatus), default=PlotStatus.ACTIVE)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    # Relationships
    members = relationship("MemberPlot", back_populates="plot", cascade="all, delete-orphan")
    ownership_history = relationship("OwnershipHistory", back_populates="plot", cascade="all, delete-orphan")


# ============================================
# Member-Plot relationship (many-to-many)
# ============================================
class MemberPlot(Base):
    __tablename__ = "member_plots"

    id = Column(Integer, primary_key=True, index=True)
    member_id = Column(Integer, ForeignKey("members.id"), nullable=False)
    plot_id = Column(Integer, ForeignKey("plots.id"), nullable=False)
    ownership_share = Column(DECIMAL(5, 2), default=100.00)  # percentage
    created_at = Column(DateTime, default=func.now())

    # Relationships
    member = relationship("Member", back_populates="plots")
    plot = relationship("Plot", back_populates="members")


# ============================================
# Ownership History (история владения)
# ============================================
class OwnershipHistory(Base):
    __tablename__ = "ownership_history"

    id = Column(Integer, primary_key=True, index=True)
    member_id = Column(Integer, ForeignKey("members.id"), nullable=False)
    plot_id = Column(Integer, ForeignKey("plots.id"), nullable=False)
    transfer_date = Column(Date, nullable=False)
    transfer_type = Column(SQLEnum(OwnershipType), nullable=False)
    document_number = Column(String(100))
    comment = Column(Text)
    created_at = Column(DateTime, default=func.now())

    # Relationships
    member = relationship("Member", back_populates="ownership_history")
    plot = relationship("Plot", back_populates="ownership_history")


# ============================================
# Fee Types (виды взносов)
# ============================================
class FeeTypeModel(Base):
    __tablename__ = "fee_types"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    code = Column(SQLEnum(FeeType), unique=True, nullable=False)
    description = Column(Text)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.now())

    # Relationships
    rates = relationship("FeeRate", back_populates="fee_type")
    accruals = relationship("FeeAccrual", back_populates="fee_type")


# ============================================
# Fee Rates (ставки взносов по годам)
# ============================================
class FeeRate(Base):
    __tablename__ = "fee_rates"

    id = Column(Integer, primary_key=True, index=True)
    fee_type_id = Column(Integer, ForeignKey("fee_types.id"), nullable=False)
    year = Column(Integer, nullable=False)
    rate = Column(DECIMAL(10, 2), nullable=False)  # rate per sotka
    unit = Column(String(20), default="sotka")  # sotka, fixed, etc.
    created_at = Column(DateTime, default=func.now())

    # Relationships
    fee_type = relationship("FeeTypeModel", back_populates="rates")

    __table_args__ = (
        # Unique constraint for fee_type + year
        sqlalchemy.UniqueConstraint('fee_type_id', 'year', name='uq_fee_type_year'),
    )


# ============================================
# Fee Accruals (начисления)
# ============================================
class FeeAccrual(Base):
    __tablename__ = "fee_accruals"

    id = Column(Integer, primary_key=True, index=True)
    member_id = Column(Integer, ForeignKey("members.id"), nullable=False)
    fee_type_id = Column(Integer, ForeignKey("fee_types.id"), nullable=False)
    year = Column(Integer, nullable=False)
    amount = Column(DECIMAL(10, 2), nullable=False)
    paid_amount = Column(DECIMAL(10, 2), default=0.00)
    is_paid = Column(Boolean, default=False)
    due_date = Column(Date)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    # Relationships
    member = relationship("Member", back_populates="accruals")
    fee_type = relationship("FeeTypeModel", back_populates="accruals")
    payment_splits = relationship("PaymentSplit", back_populates="accrual")

    @property
    def remaining_amount(self) -> float:
        return float(self.amount) - float(self.paid_amount)


# ============================================
# Fee Payments (платежи)
# ============================================
class FeePayment(Base):
    __tablename__ = "fee_payments"

    id = Column(Integer, primary_key=True, index=True)
    member_id = Column(Integer, ForeignKey("members.id"), nullable=False)
    amount = Column(DECIMAL(10, 2), nullable=False)
    payment_date = Column(Date, nullable=False)
    payment_method = Column(SQLEnum(PaymentMethod), default=PaymentMethod.CASH)
    comment = Column(Text)
    receipt_number = Column(String(50), unique=True)
    receipt_generated = Column(Boolean, default=False)
    created_at = Column(DateTime, default=func.now())
    created_by = Column(Integer, ForeignKey("users.id"))

    # Relationships
    member = relationship("Member", back_populates="payments")
    splits = relationship("PaymentSplit", back_populates="payment", cascade="all, delete-orphan")


# ============================================
# Payment Splits (распределение платежей)
# ============================================
class PaymentSplit(Base):
    __tablename__ = "payment_splits"

    id = Column(Integer, primary_key=True, index=True)
    payment_id = Column(Integer, ForeignKey("fee_payments.id"), nullable=False)
    accrual_id = Column(Integer, ForeignKey("fee_accruals.id"), nullable=False)
    amount = Column(DECIMAL(10, 2), nullable=False)
    created_at = Column(DateTime, default=func.now())

    # Relationships
    payment = relationship("FeePayment", back_populates="splits")
    accrual = relationship("FeeAccrual", back_populates="payment_splits")


# ============================================
# Member Debts (текущие задолженности)
# ============================================
class MemberDebt(Base):
    __tablename__ = "member_debts"

    id = Column(Integer, primary_key=True, index=True)
    member_id = Column(Integer, ForeignKey("members.id"), nullable=False)
    total_debt = Column(DECIMAL(10, 2), default=0.00)
    debt_category = Column(SQLEnum(DebtCategory))
    last_updated = Column(DateTime, default=func.now(), onupdate=func.now())

    # Relationships
    member = relationship("Member", back_populates="debts")


# ============================================
# Receipts (квитанции)
# ============================================
class Receipt(Base):
    __tablename__ = "receipts"

    id = Column(Integer, primary_key=True, index=True)
    payment_id = Column(Integer, ForeignKey("fee_payments.id"), nullable=False)
    receipt_number = Column(String(50), unique=True, nullable=False)
    file_path = Column(String(255))
    generated_at = Column(DateTime, default=func.now())
    generated_by = Column(Integer, ForeignKey("users.id"))

    # Relationships
    payment = relationship("FeePayment")


# ============================================
# Action Logs (логи действий)
# ============================================
class ActionLog(Base):
    __tablename__ = "action_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    action = Column(String(100), nullable=False)
    entity_type = Column(String(50))
    entity_id = Column(Integer)
    old_values = Column(Text)  # JSON
    new_values = Column(Text)  # JSON
    created_at = Column(DateTime, default=func.now())

    # Relationships
    user = relationship("User", back_populates="action_logs")


# Import sqlalchemy for UniqueConstraint
import sqlalchemy
