import React, { useEffect, useState } from 'react';
import { Card, Row, Col, Statistic, Table, Typography, Spin, Tag } from 'antd';
import {
  TeamOutlined,
  WarningOutlined,
  DollarOutlined,
  CheckCircleOutlined,
} from '@ant-design/icons';
import { dashboardApi } from '@/services/api';
import type { DashboardData, MemberListItem } from '@/types/api';
import { Pie } from '@ant-design/charts';

const { Title } = Typography;

const Dashboard: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<DashboardData | null>(null);

  useEffect(() => {
    loadDashboard();
  }, []);

  const loadDashboard = async () => {
    try {
      setLoading(true);
      const result = await dashboardApi.getDashboard();
      setData(result);
    } catch (error) {
      console.error('Failed to load dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: 64 }}>
        <Spin size="large" />
      </div>
    );
  }

  if (!data) {
    return null;
  }

  const { stats, member_status_chart, top_debtors, recent_payments } = data;

  // Member status chart config
  const pieConfig = {
    appendPadding: 10,
    data: member_status_chart,
    angleField: 'value',
    colorField: 'label',
    radius: 0.8,
    label: {
      type: 'outer',
      content: '{name} {percentage}',
    },
    interactions: [{ type: 'element-active' }],
    color: ['#52c41a', '#faad14', '#8c8c8c', '#ff4d4f'],
  };

  // Debtors table columns
  const debtorsColumns = [
    {
      title: 'ФИО',
      dataIndex: 'full_name',
      key: 'full_name',
    },
    {
      title: 'Телефон',
      dataIndex: 'phone',
      key: 'phone',
    },
    {
      title: 'Долг',
      dataIndex: 'total_debt',
      key: 'total_debt',
      render: (value: number) => (
        <span style={{ color: '#ff4d4f', fontWeight: 'bold' }}>
          {value.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' })}
        </span>
      ),
    },
    {
      title: 'Категория',
      dataIndex: 'debt_category',
      key: 'debt_category',
      render: (category: string) => {
        const colorMap: Record<string, string> = {
          small: 'orange',
          medium: 'volcano',
          large: 'red',
        };
        const labelMap: Record<string, string> = {
          small: 'Мелкий',
          medium: 'Средний',
          large: 'Крупный',
        };
        return <Tag color={colorMap[category]}>{labelMap[category] || category}</Tag>;
      },
    },
  ];

  // Recent payments columns
  const paymentsColumns = [
    {
      title: 'Дата',
      dataIndex: 'payment_date',
      key: 'payment_date',
      render: (date: string) => new Date(date).toLocaleDateString('ru-RU'),
    },
    {
      title: 'Член СНТ',
      dataIndex: 'member_name',
      key: 'member_name',
    },
    {
      title: 'Сумма',
      dataIndex: 'amount',
      key: 'amount',
      render: (value: number) => (
        <span style={{ color: '#52c41a', fontWeight: 'bold' }}>
          +{value.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' })}
        </span>
      ),
    },
    {
      title: 'Квитанция',
      dataIndex: 'receipt_number',
      key: 'receipt_number',
      render: (receipt: string) => receipt || '—',
    },
  ];

  return (
    <div>
      <Title level={2} style={{ marginBottom: 24 }}>Дашборд</Title>

      {/* Statistics Cards */}
      <Row gutter={[16, 16]} style={{ marginBottom: 24 }}>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Всего членов"
              value={stats.total_members}
              prefix={<TeamOutlined />}
              valueStyle={{ color: '#1890ff' }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Действительных членов"
              value={stats.active_members}
              suffix={`/ ${stats.total_members}`}
              valueStyle={{ color: '#52c41a' }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Должников"
              value={stats.debtors_count}
              prefix={<WarningOutlined />}
              valueStyle={{ color: '#faad14' }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Общий долг"
              value={stats.total_debt}
              precision={2}
              prefix={<DollarOutlined />}
              valueStyle={{ color: '#ff4d4f' }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Собрано взносов"
              value={stats.total_collected}
              precision={2}
              prefix={<CheckCircleOutlined />}
              valueStyle={{ color: '#52c41a' }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Участков"
              value={stats.plots_count}
              valueStyle={{ color: '#722ed1' }}
            />
          </Card>
        </Col>
      </Row>

      {/* Charts and Tables */}
      <Row gutter={[16, 16]}>
        <Col xs={24} lg={12}>
          <Card title="Состав членов СНТ">
            <Pie {...pieConfig} height={300} />
          </Card>
        </Col>
        <Col xs={24} lg={12}>
          <Card title="Крупные должники">
            <Table
              columns={debtorsColumns}
              dataSource={top_debtors}
              rowKey="id"
              pagination={false}
              size="small"
              scroll={{ y: 300 }}
            />
          </Card>
        </Col>
      </Row>

      <Row gutter={[16, 16]} style={{ marginTop: 16 }}>
        <Col xs={24}>
          <Card title="Последние платежи">
            <Table
              columns={paymentsColumns}
              dataSource={recent_payments}
              rowKey="id"
              pagination={false}
              size="small"
            />
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default Dashboard;
