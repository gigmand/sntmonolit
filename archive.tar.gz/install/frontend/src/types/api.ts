// API Types for SNT Monolit

export type UserRole = 'admin' | 'chairman' | 'treasurer' | 'secretary' | 'observer';

export type MemberStatus = 'active' | 'debtor' | 'former' | 'deceased';

export type PlotStatus = 'active' | 'inactive' | 'archived';

export type OwnershipType = 'sale' | 'inheritance' | 'gift' | 'other';

export type FeeTypeCode = 'member' | 'target' | 'electricity';

export type PaymentMethod = 'cash' | 'bank_transfer' | 'card';

export type DebtCategory = 'small' | 'medium' | 'large';

// User
export interface User {
  id: number;
  username: string;
  email: string;
  full_name: string;
  role: UserRole;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// Member
export interface Member {
  id: number;
  first_name: string;
  last_name: string;
  middle_name: string | null;
  birth_date: string | null;
  phone: string | null;
  email: string | null;
  address: string | null;
  membership_start_date: string | null;
  membership_end_date: string | null;
  status: MemberStatus;
  status_comment: string | null;
  has_irrigation: boolean;
  full_name: string;
  has_debt: boolean;
  created_at: string;
  updated_at: string;
}

export interface MemberListItem extends Member {
  plot_count: number;
  total_debt: number;
}

export interface PlotInfo {
  id: number;
  plot_number: string;
  alley: string | null;
  cadastral_number: string | null;
  area: number;
  ownership_share: number;
}

export interface MemberDetail extends Member {
  plots: PlotInfo[];
  total_debt: number;
  debt_category: DebtCategory | null;
}

// Plot
export interface Plot {
  id: number;
  plot_number: string;
  alley: string | null;
  cadastral_number: string | null;
  area: number;
  status: PlotStatus;
  created_at: string;
  updated_at: string;
}

export interface PlotListItem extends Plot {
  member_names: string[];
}

export interface MemberInfo {
  id: number;
  full_name: string;
  ownership_share: number;
}

export interface OwnershipHistoryItem {
  id: number;
  member_id: number;
  plot_id: number;
  transfer_date: string;
  transfer_type: OwnershipType;
  document_number: string | null;
  comment: string | null;
  member_name: string;
  plot_number: string;
  created_at: string;
}

export interface PlotDetail extends Plot {
  members: MemberInfo[];
  ownership_history: OwnershipHistoryItem[];
}

// Fees
export interface FeeType {
  id: number;
  name: string;
  code: FeeTypeCode;
  description: string | null;
  is_active: boolean;
  created_at: string;
}

export interface FeeRate {
  id: number;
  fee_type_id: number;
  year: number;
  rate: number;
  unit: string;
  fee_type_name: string;
  created_at: string;
}

export interface FeeAccrual {
  id: number;
  member_id: number;
  fee_type_id: number;
  year: number;
  amount: number;
  paid_amount: number;
  remaining_amount: number;
  is_paid: boolean;
  due_date: string | null;
  member_name: string;
  fee_type_name: string;
  created_at: string;
}

export interface PaymentSplit {
  id: number;
  payment_id: number;
  accrual_id: number;
  amount: number;
}

export interface FeePayment {
  id: number;
  member_id: number;
  amount: number;
  payment_date: string;
  payment_method: PaymentMethod;
  comment: string | null;
  receipt_number: string | null;
  receipt_generated: boolean;
  member_name: string;
  created_at: string;
  created_by: number | null;
}

export interface FeePaymentDetail extends FeePayment {
  splits: PaymentSplit[];
}

// Dashboard
export interface DashboardStats {
  total_members: number;
  active_members: number;
  debtors_count: number;
  total_debt: number;
  total_collected: number;
  plots_count: number;
}

export interface ChartDataPoint {
  label: string;
  value: number;
}

export interface DashboardData {
  stats: DashboardStats;
  member_status_chart: ChartDataPoint[];
  monthly_income: ChartDataPoint[];
  top_debtors: MemberListItem[];
  recent_payments: FeePayment[];
}

// Auth
export interface LoginRequest {
  username: string;
  password: string;
}

export interface TokenResponse {
  access_token: string;
  token_type: string;
}

// API Response types
export interface ApiResponse<T> {
  data?: T;
  error?: string;
  message?: string;
}
