import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ConfigProvider } from 'antd';
import ruRU from 'antd/locale/ru_RU';
import dayjs from 'dayjs';
import 'dayjs/locale/ru';

import AppLayout from '@/components/AppLayout';
import Login from '@/pages/Login';
import Dashboard from '@/pages/Dashboard';
import Members from '@/pages/Members';
import Plots from '@/pages/Plots';
import Payments from '@/pages/Payments';
import Accruals from '@/pages/Accruals';
import Reports from '@/pages/Reports';
import FeeTypes from '@/pages/FeeTypes';

import { useAuthStore } from '@/store/authStore';

dayjs.locale('ru');

// Protected Route component
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
};

// App content with auth check
const AppContent: React.FC = () => {
  const checkAuth = useAuthStore((state) => state.checkAuth);
  const [checked, setChecked] = React.useState(false);

  React.useEffect(() => {
    checkAuth().finally(() => setChecked(true));
  }, []);

  if (!checked) {
    return (
      <div style={{
        height: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}>
        Загрузка...
      </div>
    );
  }

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        path="/"
        element={
          <ProtectedRoute>
            <AppLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Dashboard />} />
        <Route path="members" element={<Members />} />
        <Route path="plots" element={<Plots />} />
        <Route path="fees/accruals" element={<Accruals />} />
        <Route path="fees/payments" element={<Payments />} />
        <Route path="fees/types" element={<FeeTypes />} />
        <Route path="reports" element={<Reports />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ConfigProvider locale={ruRU}>
      <BrowserRouter>
        <AppContent />
      </BrowserRouter>
    </ConfigProvider>
  </React.StrictMode>
);
