import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { Layout, Menu, theme } from 'antd';
import type { MenuProps } from 'antd';
import {
  HomeOutlined,
  TeamOutlined,
  PropertySafetyOutlined,
  WalletOutlined,
  BarChartOutlined,
  FileTextOutlined,
  LogoutOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined,
} from '@ant-design/icons';
import { useAuthStore } from '@/store/authStore';

const { Header, Sider, Content } = Layout;

type MenuItem = Required<MenuProps>['items'][number];

function getItem(
  label: React.ReactNode,
  key: React.Key,
  icon?: React.ReactNode,
  children?: MenuItem[]
): MenuItem {
  return {
    key,
    icon,
    children,
    label,
  } as MenuItem;
}

const menuItems: MenuItem[] = [
  getItem('Дашборд', '/', <HomeOutlined />),
  getItem('Члены СНТ', '/members', <TeamOutlined />),
  getItem('Участки', '/plots', <PropertySafetyOutlined />),
  getItem(
    'Взносы и платежи',
    '/fees',
    <WalletOutlined />,
    [
      getItem('Начисления', '/fees/accruals'),
      getItem('Платежи', '/fees/payments'),
      getItem('Виды взносов', '/fees/types'),
    ]
  ),
  getItem('Отчеты', '/reports', <FileTextOutlined />),
];

const AppLayout: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();
  const {
    token: { colorBgContainer, borderRadiusLG },
  } = theme.useToken();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const logoutItem = getItem(
    <span onClick={handleLogout} style={{ color: '#ff4d4f' }}>Выйти</span>,
    'logout',
    <LogoutOutlined />
  );

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Sider trigger={null} collapsible collapsed={collapsed} theme="dark">
        <div style={{ 
          height: 32, 
          margin: 16, 
          background: 'rgba(255, 255, 255, 0.2)',
          borderRadius: 4,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#fff',
          fontWeight: 'bold',
        }}>
          {collapsed ? 'СНТ' : 'СНТ Монолит'}
        </div>
        <Menu
          theme="dark"
          mode="inline"
          selectedKeys={[location.pathname]}
          items={[...menuItems, logoutItem]}
          onClick={({ key }) => {
            if (key !== 'logout') {
              navigate(key);
            }
          }}
        />
      </Sider>
      <Layout>
        <Header style={{ padding: '0 16px', background: colorBgContainer, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            {React.createElement(collapsed ? MenuUnfoldOutlined : MenuFoldOutlined, {
              className: 'trigger',
              onClick: () => setCollapsed(!collapsed),
              style: { fontSize: 18, cursor: 'pointer' }
            })}
            <span style={{ fontSize: 16, fontWeight: 500 }}>АИС СНТ-Управление</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ color: '#666' }}>{user?.full_name}</span>
            <span style={{ 
              background: '#e6f7ff', 
              padding: '2px 8px', 
              borderRadius: 4,
              fontSize: 12,
              color: '#1890ff'
            }}>
              {user?.role === 'admin' && 'Администратор'}
              {user?.role === 'chairman' && 'Председатель'}
              {user?.role === 'treasurer' && 'Казначей'}
              {user?.role === 'secretary' && 'Секретарь'}
              {user?.role === 'observer' && 'Наблюдатель'}
            </span>
          </div>
        </Header>
        <Content
          style={{
            margin: '16px',
            padding: 24,
            minHeight: 280,
            background: colorBgContainer,
            borderRadius: borderRadiusLG,
          }}
        >
          <Outlet />
        </Content>
      </Layout>
    </Layout>
  );
};

export default AppLayout;
