# Инструкция по установке АИС "СНТ-Управление" (без Docker)

## Требования к серверу

### Минимальные
- Процессор: 2 ядра, 2.0 GHz
- Оперативная память: 4 GB
- Дисковое пространство: 50 GB SSD
- ОС: Ubuntu 20.04/22.04 LTS

### Рекомендуемые
- Процессор: 4 ядра, 2.5 GHz
- Оперативная память: 8 GB
- Дисковое пространство: 100 GB SSD

## Быстрая установка (автоматическая)

```bash
# Перейти в директорию установки
cd /opt/monolit/install

# Сделать скрипт исполняемым
chmod +x install.sh

# Запустить установку от имени root
sudo ./install.sh
```

После установки откройте в браузере: `http://your-server-ip`

**Учетные данные по умолчанию:**
- Логин: `admin`
- Пароль: `admin123`

---

## Пошаговая установка (вручную)

### Шаг 1: Установка системных зависимостей

```bash
# Обновление пакетов
sudo apt update && sudo apt upgrade -y

# Установка зависимостей
sudo apt install -y \
    python3.11 python3.11-venv python3.11-dev python3-pip \
    nodejs npm \
    mariadb-server mariadb-client libmariadb-dev \
    nginx \
    libpango-1.0-0 libpangocairo-1.0-0 libgdk-pixbuf2.0-0 \
    libffi-dev shared-mime-info \
    openssl curl wget git
```

### Шаг 2: Настройка базы данных

```bash
# Запуск MariaDB
sudo systemctl start mariadb
sudo systemctl enable mariadb

# Создание БД и пользователя
sudo mysql -u root <<EOF
CREATE DATABASE IF NOT EXISTS snt_monolit CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'snt_user'@'localhost' IDENTIFIED BY 'snt_password_change_me';
GRANT ALL PRIVILEGES ON snt_monolit.* TO 'snt_user'@'localhost';
FLUSH PRIVILEGES;
EOF
```

### Шаг 3: Настройка Backend

```bash
cd /opt/monolit/backend

# Создание виртуального окружения
python3.11 -m venv venv
source venv/bin/activate

# Установка зависимостей
pip install --upgrade pip
pip install -r requirements.txt

# Настройка окружения
cp .env.example .env
nano .env  # Отредактируйте DB_PASSWORD и SECRET_KEY

# Создание директорий
mkdir -p /opt/monolit/uploads/receipts
sudo chown -R www-data:www-data /opt/monolit/uploads

# Инициализация БД
python init_db.py

deactivate
```

### Шаг 4: Настройка Frontend

```bash
cd /opt/monolit/frontend

# Установка зависимостей
npm install --legacy-peer-deps

# Сборка production версии
npm run build

# Копирование в nginx
sudo cp -r dist/* /var/www/html/
```

### Шаг 5: Настройка Nginx

```bash
sudo nano /etc/nginx/sites-available/snt-monolit
```

Конфигурация:

```nginx
server {
    listen 80;
    server_name _;
    root /var/www/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    location /docs {
        proxy_pass http://127.0.0.1:8000/docs;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location /openapi.json {
        proxy_pass http://127.0.0.1:8000/openapi.json;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
    }
}
```

Активация:

```bash
sudo ln -s /etc/nginx/sites-available/snt-monolit /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl restart nginx
sudo systemctl enable nginx
```

### Шаг 6: Настройка systemd для backend

```bash
sudo nano /etc/systemd/system/snt-backend.service
```

```ini
[Unit]
Description=SNT Monolit Backend
After=network.target mariadb.service

[Service]
User=www-data
Group=www-data
WorkingDirectory=/opt/monolit/backend
Environment="PATH=/opt/monolit/backend/venv/bin"
ExecStart=/opt/monolit/backend/venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 8000 --workers 2
Restart=always
RestartSec=5

# Security
NoNewPrivileges=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable snt-backend
sudo systemctl start snt-backend
sudo systemctl status snt-backend
```

---

## Резервное копирование

### Настройка автоматического бэкапа

```bash
# Перейти в директорию установки
cd /opt/monolit/install

# Сделать скрипт исполняемым
chmod +x backup.sh

# Тестовый запуск
sudo ./backup.sh
```

### Cron для ежедневного бэкапа

```bash
sudo crontab -e
```

Добавьте строку:
```
0 2 * * * /opt/monolit/install/backup.sh
```

---

## Управление сервисами

```bash
# Backend
sudo systemctl start snt-backend
sudo systemctl stop snt-backend
sudo systemctl restart snt-backend
sudo systemctl status snt-backend
sudo journalctl -u snt-backend -f

# Nginx
sudo systemctl start nginx
sudo systemctl stop nginx
sudo systemctl restart nginx
sudo systemctl status nginx

# MariaDB
sudo systemctl start mariadb
sudo systemctl stop mariadb
sudo systemctl restart mariadb
sudo systemctl status mariadb
```

---

## Устранение неполадок

### Проверка логов

```bash
# Backend
sudo journalctl -u snt-backend -f

# Nginx
sudo tail -f /var/log/nginx/error.log
sudo tail -f /var/log/nginx/access.log

# MariaDB
sudo tail -f /var/log/mysql/error.log
```

### Проверка подключения к БД

```bash
mysql -h localhost -u snt_user -p snt_monolit
```

### Перезапуск всех сервисов

```bash
sudo systemctl restart mariadb snt-backend nginx
```

### Проверка портов

```bash
# Должны быть открыты: 80 (nginx), 3306 (mariadb)
sudo ss -tlnp | grep -E ':(80|3306|8000)'
```

---

## Безопасность

1. **Смените пароль администратора** после первого входа
2. **Измените SECRET_KEY** в `/opt/monolit/backend/.env`
3. **Измените пароль БД** в `/opt/monolit/backend/.env`

### Настройка HTTPS через Let's Encrypt

```bash
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d your-domain.com
```

### Настройка firewall

```bash
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
sudo ufw status
```

---

## Обновление

```bash
# Остановка backend
sudo systemctl stop snt-backend

# Обновление кода (если используете git)
cd /opt/monolit
git pull  # или скопируйте новые файлы

# Backend
cd /opt/monolit/backend
source venv/bin/activate
pip install -r requirements.txt
python init_db.py  # если есть миграции
deactivate

# Frontend
cd /opt/monolit/frontend
npm install
npm run build
sudo cp -r dist/* /var/www/html/

# Запуск
sudo systemctl start snt-backend
sudo systemctl restart nginx
```

---

При возникновении проблем обратитесь к документации или в службу поддержки.
