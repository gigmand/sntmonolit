"""
Fees and Payments API endpoints
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query, Response
from sqlalchemy.orm import Session
from typing import Optional, List
from datetime import date

from app.db.database import get_db
from app.api.auth import get_current_user
from app.services import (
    FeeTypeService, FeeRateService, FeeAccrualService, PaymentService,
    MemberService
)
from app.schemas import (
    FeeTypeCreate, FeeTypeUpdate, FeeTypeResponse,
    FeeRateCreate, FeeRateUpdate, FeeRateResponse,
    FeeAccrualCreate, FeeAccrualUpdate, FeeAccrualResponse,
    FeePaymentCreate, FeePaymentUpdate, FeePaymentResponse, FeePaymentDetail,
    PaymentSplitResponse,
    UserResponse, FeeTypeResponse as FeeTypeSchema, MemberStatusEnum
)
from app.models import FeeTypeModel, FeeRate, FeeAccrual, FeePayment, Member
from app.utils.receipt_generator import ReceiptGenerator
from app.core.config import settings
from fastapi.responses import FileResponse
import os

router = APIRouter(prefix="/fees", tags=["Fees"])


# ============================================
# Fee Types
# ============================================
@router.get("/types", response_model=List[FeeTypeResponse])
def get_fee_types(
    active_only: bool = True,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Get all fee types."""
    return FeeTypeService.get_all(db, active_only=active_only)


@router.post("/types", response_model=FeeTypeResponse, status_code=status.HTTP_201_CREATED)
def create_fee_type(
    fee_type: FeeTypeCreate,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Create a new fee type."""
    return FeeTypeService.create(db, fee_type)


@router.put("/types/{fee_type_id}", response_model=FeeTypeResponse)
def update_fee_type(
    fee_type_id: int,
    fee_type_update: FeeTypeUpdate,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Update a fee type."""
    ft = FeeTypeService.get_by_id(db, fee_type_id)
    if not ft:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Fee type not found"
        )
    return FeeTypeService.update(db, ft, fee_type_update)


# ============================================
# Fee Rates
# ============================================
@router.get("/rates", response_model=List[FeeRateResponse])
def get_fee_rates(
    year: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Get fee rates, optionally filtered by year."""
    if year:
        rates = FeeRateService.get_by_year(db, year)
    else:
        rates = db.query(FeeRate).all()
    
    result = []
    for rate in rates:
        result.append({
            "id": rate.id,
            "fee_type_id": rate.fee_type_id,
            "year": rate.year,
            "rate": float(rate.rate),
            "unit": rate.unit,
            "fee_type_name": rate.fee_type.name,
            "created_at": rate.created_at
        })
    return result


@router.post("/rates", response_model=FeeRateResponse, status_code=status.HTTP_201_CREATED)
def create_fee_rate(
    fee_rate: FeeRateCreate,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Create or update a fee rate."""
    return FeeRateService.create(db, fee_rate)


# ============================================
# Fee Accruals
# ============================================
@router.get("/accruals")
def get_accruals(
    member_id: Optional[int] = None,
    year: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Get fee accruals with optional filters."""
    if member_id:
        accruals = FeeAccrualService.get_by_member(db, member_id, year)
    elif year:
        accruals = FeeAccrualService.get_by_year(db, year)
    else:
        accruals = db.query(FeeAccrual).all()

    result = []
    for a in accruals:
        result.append({
            "id": a.id,
            "member_id": a.member_id,
            "fee_type_id": a.fee_type_id,
            "year": a.year,
            "amount": float(a.amount),
            "paid_amount": float(a.paid_amount),
            "remaining_amount": a.remaining_amount,
            "is_paid": a.is_paid,
            "due_date": a.due_date,
            "member_name": a.member.full_name,
            "fee_type_name": a.fee_type.name,
            "created_at": a.created_at
        })
    return result


@router.post("/accruals", response_model=FeeAccrualResponse, status_code=status.HTTP_201_CREATED)
def create_accrual(
    accrual: FeeAccrualCreate,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Create a new fee accrual."""
    member = MemberService.get_by_id(db, accrual.member_id)
    if not member:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Member not found"
        )
    
    fee_type = FeeTypeService.get_by_id(db, accrual.fee_type_id)
    if not fee_type:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Fee type not found"
        )
    
    return FeeAccrualService.create(db, accrual)


@router.post("/accruals/bulk", status_code=status.HTTP_201_CREATED)
def create_bulk_accruals(
    fee_type_id: int,
    year: int,
    rate_per_sotka: float,
    due_date: date,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Create accruals for all active members based on their plot area."""
    fee_type = FeeTypeService.get_by_id(db, fee_type_id)
    if not fee_type:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Fee type not found"
        )
    
    accruals = FeeAccrualService.create_for_all_members(
        db, fee_type_id, year, rate_per_sotka, due_date
    )
    
    return {"message": f"Created {len(accruals)} accruals"}


@router.put("/accruals/{accrual_id}", response_model=FeeAccrualResponse)
def update_accrual(
    accrual_id: int,
    accrual_update: FeeAccrualUpdate,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Update a fee accrual."""
    accrual = FeeAccrualService.get_by_id(db, accrual_id)
    if not accrual:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Accrual not found"
        )
    return FeeAccrualService.update(db, accrual, accrual_update)


# ============================================
# Payments
# ============================================
@router.get("/payments", response_model=List[FeePaymentResponse])
def get_payments(
    member_id: Optional[int] = None,
    limit: int = Query(100, ge=1, le=500),
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Get payments with optional member filter."""
    if member_id:
        payments = PaymentService.get_by_member(db, member_id)
    else:
        payments = PaymentService.get_recent(db, limit=limit)
    
    result = []
    for p in payments:
        result.append({
            "id": p.id,
            "member_id": p.member_id,
            "amount": float(p.amount),
            "payment_date": p.payment_date,
            "payment_method": p.payment_method.value,
            "comment": p.comment,
            "receipt_number": p.receipt_number,
            "receipt_generated": p.receipt_generated,
            "member_name": p.member.full_name,
            "created_at": p.created_at,
            "created_by": p.created_by
        })
    return result


@router.get("/payments/{payment_id}", response_model=FeePaymentDetail)
def get_payment(
    payment_id: int,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Get payment by ID with splits."""
    payment = PaymentService.get_by_id(db, payment_id)
    if not payment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Payment not found"
        )
    
    splits = []
    for s in payment.splits:
        splits.append({
            "id": s.id,
            "payment_id": s.payment_id,
            "accrual_id": s.accrual_id,
            "amount": float(s.amount)
        })
    
    return {
        "id": payment.id,
        "member_id": payment.member_id,
        "amount": float(payment.amount),
        "payment_date": payment.payment_date,
        "payment_method": payment.payment_method.value,
        "comment": payment.comment,
        "receipt_number": payment.receipt_number,
        "receipt_generated": payment.receipt_generated,
        "member_name": payment.member.full_name,
        "created_at": payment.created_at,
        "created_by": payment.created_by,
        "splits": splits
    }


@router.post("/payments", response_model=FeePaymentResponse, status_code=status.HTTP_201_CREATED)
def create_payment(
    payment: FeePaymentCreate,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Create a new payment with splits."""
    member = MemberService.get_by_id(db, payment.member_id)
    if not member:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Member not found"
        )
    
    # Validate splits
    total_split = sum(s.amount for s in payment.splits)
    if total_split > payment.amount:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Total split amount ({total_split}) exceeds payment amount ({payment.amount})"
        )
    
    db_payment = PaymentService.create(db, payment, created_by=current_user.id)

    return {
        "id": db_payment.id,
        "member_id": db_payment.member_id,
        "amount": float(db_payment.amount),
        "payment_date": db_payment.payment_date,
        "payment_method": db_payment.payment_method.value,
        "comment": db_payment.comment,
        "receipt_number": db_payment.receipt_number,
        "receipt_generated": db_payment.receipt_generated,
        "member_name": db_payment.member.full_name,
        "created_at": db_payment.created_at,
        "created_by": db_payment.created_by
    }


@router.get("/payments/{payment_id}/receipt")
def get_payment_receipt(
    payment_id: int,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Generate and open receipt PDF in browser for a payment."""
    payment = db.query(FeePayment).filter(FeePayment.id == payment_id).first()
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")
    
    # Get splits with fee type names
    splits = []
    for split in payment.splits:
        splits.append({
            "fee_type_name": split.accrual.fee_type.name,
            "year": split.accrual.year,
            "amount": float(split.amount),
        })
    
    member = payment.member
    
    # Prepare data for receipt generator
    payment_data = {
        "receipt_number": payment.receipt_number or f"KB-{payment.id}",
        "payment_date": payment.payment_date.strftime('%Y-%m-%d'),
        "member_name": member.full_name,
        "member_address": member.address,
        "member_phone": member.phone,
        "amount": float(payment.amount),
        "payment_method": payment.payment_method.value,
        "splits": splits,
        "comment": payment.comment,
    }
    
    # Generate PDF
    output_path = f"{settings.RECEIPTS_DIR}/{payment_data['receipt_number']}.pdf"
    generator = ReceiptGenerator()
    generator.generate_pdf(
        output_path=output_path,
        receipt_number=payment_data["receipt_number"],
        payment_date=payment_data["payment_date"],
        member_name=payment_data["member_name"],
        member_address=payment_data["member_address"],
        member_phone=payment_data["member_phone"],
        amount=payment_data["amount"],
        payment_method=payment_data["payment_method"],
        splits=payment_data["splits"],
        comment=payment_data["comment"],
    )
    
    return FileResponse(
        output_path,
        media_type="application/pdf",
        filename=f"{payment_data['receipt_number']}.pdf",
        headers={"Content-Disposition": f"inline; filename={payment_data['receipt_number']}.pdf"}
    )


@router.post("/payments/receipts/bulk")
def get_bulk_receipts(
    payment_id: Optional[int] = None,
    payment_ids: Optional[List[int]] = None,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Generate and open PDF with 2 identical receipts (original + copy) in browser."""
    # Use payment_id from query or from body
    if payment_id is None and (payment_ids is None or len(payment_ids) == 0):
        raise HTTPException(status_code=400, detail="payment_id or payment_ids required")
    
    pid = payment_id or (payment_ids[0] if payment_ids else None)
    
    if pid is None:
        raise HTTPException(status_code=404, detail="No payment found")
    
    payment = db.query(FeePayment).filter(FeePayment.id == pid).first()
    
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")
    
    # Get splits with fee type names
    splits = []
    for split in payment.splits:
        splits.append({
            "fee_type_name": split.accrual.fee_type.name,
            "year": split.accrual.year,
            "amount": float(split.amount),
        })
    
    member = payment.member
    
    # Get member's plots
    plots = []
    for mp in member.plots:
        plots.append({
            "plot_number": mp.plot.plot_number,
            "alley": mp.plot.alley,
        })
    
    payments_data = [{
        "receipt_number": payment.receipt_number or f"KB-{payment.id}",
        "payment_date": payment.payment_date.strftime('%Y-%m-%d'),
        "member_name": member.full_name,
        "member_address": member.address or "",
        "member_phone": member.phone or "",
        "amount": float(payment.amount),
        "payment_method": payment.payment_method.value,
        "splits": splits,
        "comment": payment.comment,
        "plots": plots,  # Add plots info
        "has_irrigation": member.has_irrigation or False,  # Add irrigation info
    }]
    
    # Generate filename
    filename = f"receipt_{payments_data[0]['receipt_number']}_dual.pdf"
    
    output_path = f"{settings.RECEIPTS_DIR}/{filename}"
    
    generator = ReceiptGenerator()
    generator.generate_pdf_dual(
        output_path=output_path,
        payments_data=payments_data,
    )
    
    return FileResponse(
        output_path,
        media_type="application/pdf",
        filename=filename,
        headers={"Content-Disposition": f"inline; filename={filename}"}
    )
