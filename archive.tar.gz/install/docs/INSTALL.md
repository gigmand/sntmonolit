# Инструкция по установке и настройке

## Требования к серверу

### Минимальные
- Процессор: 2 ядра, 2.0 GHz
- Оперативная память: 4 GB
- Дисковое пространство: 50 GB SSD
- ОС: Ubuntu 20.04/22.04 LTS

### Рекомендуемые
- Процессор: 4 ядра, 2.5 GHz
- Оперативная память: 8 GB
- Дисковое пространство: 100 GB SSD

## Установка

### Вариант 1: Docker Compose (рекомендуется)

1. **Установите Docker и Docker Compose:**

```bash
# Обновление пакетов
sudo apt update && sudo apt upgrade -y

# Установка Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Установка Docker Compose
sudo apt install docker-compose-plugin -y

# Проверка установки
docker --version
docker compose version
```

2. **Настройте проект:**

```bash
cd /opt/monolit

# Создайте директорию для загрузок
mkdir -p uploads/receipts

# Настройте переменные окружения
cp backend/.env.example backend/.env
nano backend/.env  # Отредактируйте при необходимости
```

3. **Запустите сервисы:**

```bash
# Запуск в фоновом режиме
docker compose up -d

# Проверка статуса
docker compose ps

# Просмотр логов
docker compose logs -f
```

4. **Инициализируйте базу данных:**

```bash
docker compose exec backend python init_db.py
```

5. **Проверьте доступность:**

Откройте в браузере: http://your-server-ip

Учетные данные по умолчанию:
- Логин: `admin`
- Пароль: `admin123`

### Вариант 2: Нативная установка

#### 1. Установка зависимостей

```bash
# Системные зависимости
sudo apt update
sudo apt install -y python3.11 python3.11-venv python3-pip \
                    nodejs npm nginx \
                    mariadb-server libmariadb-dev \
                    libpango-1.0-0 libpangocairo-1.0-0 \
                    libgdk-pixbuf2.0-0 libffi-dev
```

#### 2. Настройка базы данных

```bash
# Вход в MariaDB
sudo mysql -u root

# Создание БД и пользователя
CREATE DATABASE snt_monolit CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'snt_user'@'localhost' IDENTIFIED BY 'snt_password_change_me';
GRANT ALL PRIVILEGES ON snt_monolit.* TO 'snt_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

#### 3. Настройка Backend

```bash
cd /opt/monolit/backend

# Создание виртуального окружения
python3.11 -m venv venv
source venv/bin/activate

# Установка зависимостей
pip install -r requirements.txt

# Настройка окружения
cp .env.example .env
nano .env  # Отредактируйте DB_PASSWORD и SECRET_KEY

# Инициализация БД
python init_db.py

# Запуск (тест)
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

#### 4. Настройка Frontend

```bash
cd /opt/monolit/frontend

# Установка зависимостей
npm install

# Сборка production версии
npm run build

# Копирование в nginx
sudo cp -r dist/* /var/www/html/
```

#### 5. Настройка Nginx

```bash
sudo nano /etc/nginx/sites-available/snt-monolit
```

Конфигурация:

```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /var/www/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

Активация:

```bash
sudo ln -s /etc/nginx/sites-available/snt-monolit /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

#### 6. Настройка systemd для backend

```bash
sudo nano /etc/systemd/system/snt-backend.service
```

```ini
[Unit]
Description=SNT Monolit Backend
After=network.target mariadb.service

[Service]
User=www-data
WorkingDirectory=/opt/monolit/backend
ExecStart=/opt/monolit/backend/venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable snt-backend
sudo systemctl start snt-backend
sudo systemctl status snt-backend
```

## Резервное копирование

### Настройка автоматического бэкапа

```bash
sudo nano /opt/monolit/backup.sh
```

```bash
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/opt/monolit/backups"
DB_USER="snt_user"
DB_NAME="snt_monolit"

mkdir -p $BACKUP_DIR

# Бэкап базы данных
mysqldump -u $DB_USER -p'snt_password' $DB_NAME > $BACKUP_DIR/db_$DATE.sql

# Бэкап загрузок
tar -czf $BACKUP_DIR/uploads_$DATE.tar.gz /opt/monolit/uploads/

# Удаление старых бэкапов (старше 30 дней)
find $BACKUP_DIR -name "*.sql" -mtime +30 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +30 -delete
```

```bash
chmod +x /opt/monolit/backup.sh
```

### Cron для ежедневного бэкапа

```bash
sudo crontab -e
```

Добавьте строку:
```
0 2 * * * /opt/monolit/backup.sh
```

## Обновление

### Docker Compose

```bash
cd /opt/monolit

# Остановка сервисов
docker compose down

# Обновление кода
git pull  # или скопируйте новые файлы

# Пересборка и запуск
docker compose up -d --build

# Проверка
docker compose logs -f
```

### Нативная установка

```bash
# Backend
cd /opt/monolit/backend
source venv/bin/activate
pip install -r requirements.txt
sudo systemctl restart snt-backend

# Frontend
cd /opt/monolit/frontend
npm install
npm run build
sudo cp -r dist/* /var/www/html/
sudo systemctl restart nginx
```

## Устранение неполадок

### Проверка логов

```bash
# Docker
docker compose logs backend
docker compose logs frontend
docker compose logs db

# Systemd
sudo journalctl -u snt-backend -f
sudo journalctl -u nginx -f

# Nginx
sudo tail -f /var/log/nginx/error.log
```

### Проверка подключения к БД

```bash
mysql -h localhost -u snt_user -p snt_monolit
```

### Перезапуск сервисов

```bash
# Docker
docker compose restart

# Нативная
sudo systemctl restart snt-backend nginx mariadb
```

## Безопасность

1. **Смените пароль администратора** после первого входа
2. **Измените SECRET_KEY** в .env файле
3. **Настройте HTTPS** через Let's Encrypt:

```bash
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d your-domain.com
```

4. **Настройте firewall:**

```bash
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

---

При возникновении проблем обратитесь к документации или в службу поддержки.
