import React, { useEffect, useState } from 'react';
import {
  Table, Button, Space, Modal, Form, Input, InputNumber,
  DatePicker, Select, message, Drawer, Descriptions, Tag,
  Card, Row, Col, Typography, Divider, Statistic,
} from 'antd';
import type { ColumnsType } from 'antd/es/table';
import {
  PlusOutlined,
  EyeOutlined,
  WalletOutlined,
  PrinterOutlined,
} from '@ant-design/icons';
import { feesApi, membersApi } from '@/services/api';
import type { FeePayment, FeeAccrual, MemberListItem, FeeType } from '@/types/api';
import dayjs from 'dayjs';

const { Title } = Typography;
const { TextArea } = Input;

const Payments: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [payments, setPayments] = useState<FeePayment[]>([]);
  const [selectedPayment, setSelectedPayment] = useState<any>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [form] = Form.useForm();
  const [members, setMembers] = useState<MemberListItem[]>([]);
  const [accruals, setAccruals] = useState<FeeAccrual[]>([]);
  const [feeTypes, setFeeTypes] = useState<FeeType[]>([]);
  const [selectedPaymentIds, setSelectedPaymentIds] = useState<number[]>([]);

  useEffect(() => {
    loadPayments();
    loadMembers();
    loadFeeTypes();
  }, []);

  const loadPayments = async () => {
    try {
      setLoading(true);
      const data = await feesApi.getPayments({ limit: 100 });
      setPayments(data);
    } catch (error) {
      message.error('Ошибка загрузки платежей');
    } finally {
      setLoading(false);
    }
  };

  const loadMembers = async () => {
    try {
      const data = await membersApi.getAll({ limit: 100 });
      setMembers(data);
    } catch (error) {
      console.error('Failed to load members:', error);
    }
  };

  const loadFeeTypes = async () => {
    try {
      const data = await feesApi.getFeeTypes();
      setFeeTypes(data);
    } catch (error) {
      console.error('Failed to load fee types:', error);
    }
  };

  const loadAccruals = async (memberId: number) => {
    try {
      const data = await feesApi.getAccruals({ member_id: memberId });
      setAccruals(data.filter(a => a.remaining_amount > 0));
    } catch (error) {
      console.error('Failed to load accruals:', error);
    }
  };

  const handleView = async (id: number) => {
    try {
      const payment = await feesApi.getPaymentById(id);
      setSelectedPayment(payment);
      setDrawerOpen(true);
    } catch (error) {
      message.error('Ошибка загрузки данных');
    }
  };

  const handlePrintReceipt = async (paymentId: number) => {
    try {
      const token = localStorage.getItem('access_token');
      // Open PDF in new tab
      const url = `/api/fees/payments/${paymentId}/receipt`;
      const newWindow = window.open(url, '_blank');
      
      // Add auth token to request
      if (newWindow) {
        // Fetch the PDF and display it
        const response = await fetch(url, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        
        if (!response.ok) throw new Error('Failed to generate receipt');
        
        const blob = await response.blob();
        const pdfUrl = window.URL.createObjectURL(blob);
        newWindow.location.href = pdfUrl;
      }
      
      message.success('Квитанция формируется');
    } catch (error: any) {
      message.error('Ошибка формирования квитанции: ' + error.message);
    }
  };

  const handleBulkPrint = async () => {
    if (selectedPaymentIds.length === 0) {
      message.warning('Выберите платеж для печати');
      return;
    }
    
    try {
      const token = localStorage.getItem('access_token');
      const paymentId = selectedPaymentIds[0];
      
      // Open PDF in new tab
      const url = `/api/fees/payments/receipts/bulk?payment_id=${paymentId}`;
      const newWindow = window.open(url, '_blank');
      
      // Fetch the PDF and display it
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ payment_ids: [paymentId] }),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Failed to generate receipts');
      }
      
      const blob = await response.blob();
      const pdfUrl = window.URL.createObjectURL(blob);
      if (newWindow) {
        newWindow.location.href = pdfUrl;
      }
      
      message.success('Квитанция формируется');
    } catch (error: any) {
      message.error('Ошибка формирования квитанции: ' + error.message);
    }
  };

  const handleCreate = () => {
    form.resetFields();
    setAccruals([]);
    setModalOpen(true);
  };

  const handleMemberChange = async (memberId: number) => {
    form.setFieldsValue({ member_id: memberId });
    await loadAccruals(memberId);
  };

  const handleSave = async () => {
    try {
      const values = await form.validateFields();
      
      // Calculate total from splits
      const splits = values.splits?.filter((s: any) => s.amount > 0).map((s: any) => ({
        accrual_id: s.accrual_id,
        amount: parseFloat(s.amount),
      })) || [];

      const totalAmount = splits.reduce((sum: number, s: any) => sum + s.amount, 0);

      const paymentData = {
        member_id: values.member_id,
        amount: totalAmount || parseFloat(values.amount),
        payment_date: values.payment_date.format('YYYY-MM-DD'),
        payment_method: values.payment_method,
        comment: values.comment,
        splits,
      };

      await feesApi.createPayment(paymentData);
      message.success('Платеж зарегистрирован');
      
      setModalOpen(false);
      loadPayments();
    } catch (error: any) {
      if (error?.response?.data?.detail) {
        message.error(error.response.data.detail);
      }
    }
  };

  const columns: ColumnsType<FeePayment> = [
    {
      title: '',
      key: 'select',
      width: 50,
      render: (_, record) => (
        <input
          type="checkbox"
          checked={selectedPaymentIds.includes(record.id)}
          onChange={(e) => {
            if (e.target.checked) {
              setSelectedPaymentIds([record.id]);
            } else {
              setSelectedPaymentIds([]);
            }
          }}
        />
      ),
    },
    {
      title: 'Дата',
      dataIndex: 'payment_date',
      key: 'payment_date',
      render: (date: string) => new Date(date).toLocaleDateString('ru-RU'),
      sorter: (a, b) => new Date(a.payment_date).getTime() - new Date(b.payment_date).getTime(),
    },
    {
      title: 'Член СНТ',
      dataIndex: 'member_name',
      key: 'member_name',
    },
    {
      title: 'Сумма',
      dataIndex: 'amount',
      key: 'amount',
      render: (value: number) => (
        <span style={{ color: '#52c41a', fontWeight: 'bold' }}>
          {value.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' })}
        </span>
      ),
      sorter: (a, b) => a.amount - b.amount,
    },
    {
      title: 'Способ',
      dataIndex: 'payment_method',
      key: 'payment_method',
      render: (method: string) => {
        const labels: Record<string, string> = {
          cash: 'Наличные',
          bank_transfer: 'Банковский перевод',
          card: 'Карта',
        };
        return labels[method] || method;
      },
    },
    {
      title: 'Квитанция',
      dataIndex: 'receipt_number',
      key: 'receipt_number',
      render: (receipt: string) => receipt || '—',
    },
    {
      title: 'Действия',
      key: 'actions',
      render: (_, record) => (
        <Space>
          <Button
            type="link"
            icon={<PrinterOutlined />}
            onClick={() => handlePrintReceipt(record.id)}
            title="Печать квитанции"
          />
          <Button
            type="link"
            icon={<EyeOutlined />}
            onClick={() => handleView(record.id)}
          />
        </Space>
      ),
    },
  ];

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <Title level={2} style={{ margin: 0 }}>Платежи</Title>
        <Space>
          <Button 
            onClick={handleBulkPrint} 
            disabled={selectedPaymentIds.length === 0}
            icon={<PrinterOutlined />}
          >
            Печать (оригинал + копия)
          </Button>
          <Button type="primary" icon={<PlusOutlined />} onClick={handleCreate}>
            Зарегистрировать платеж
          </Button>
        </Space>
      </div>

      <Card style={{ marginBottom: 16 }}>
        <Row gutter={16}>
          <Col span={6}>
            <Statistic title="Всего платежей" value={payments.length} prefix={<WalletOutlined />} />
          </Col>
          <Col span={6}>
            <Statistic
              title="Общая сумма"
              value={payments.reduce((sum, p) => sum + p.amount, 0)}
              precision={2}
              prefix="₽"
            />
          </Col>
        </Row>
      </Card>

      <Table
        columns={columns}
        dataSource={payments}
        rowKey="id"
        loading={loading}
        scroll={{ x: 800 }}
      />

      {/* View Drawer */}
      <Drawer
        title="Информация о платеже"
        placement="right"
        width={600}
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
      >
        {selectedPayment && (
          <>
            <Descriptions column={1} bordered>
              <Descriptions.Item label="Номер квитанции">
                {selectedPayment.receipt_number || 'Не сгенерирована'}
              </Descriptions.Item>
              <Descriptions.Item label="Дата">
                {new Date(selectedPayment.payment_date).toLocaleDateString('ru-RU')}
              </Descriptions.Item>
              <Descriptions.Item label="Член СНТ">{selectedPayment.member_name}</Descriptions.Item>
              <Descriptions.Item label="Сумма">
                <span style={{ color: '#52c41a', fontWeight: 'bold' }}>
                  {selectedPayment.amount.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' })}
                </span>
              </Descriptions.Item>
              <Descriptions.Item label="Способ оплаты">
                {selectedPayment.payment_method === 'cash' && 'Наличные'}
                {selectedPayment.payment_method === 'bank_transfer' && 'Банковский перевод'}
                {selectedPayment.payment_method === 'card' && 'Карта'}
              </Descriptions.Item>
              <Descriptions.Item label="Комментарий">
                {selectedPayment.comment || '—'}
              </Descriptions.Item>
            </Descriptions>

            <Divider>Распределение платежа</Divider>
            
            {selectedPayment.splits?.length > 0 ? (
              <Table
                columns={[
                  {
                    title: 'Начисление',
                    dataIndex: 'accrual_id',
                    key: 'accrual_id',
                    render: (id: number) => {
                      const accrual = accruals.find(a => a.id === id);
                      return accrual ? `${accrual.fee_type_name} (${accrual.year})` : `ID: ${id}`;
                    },
                  },
                  {
                    title: 'Сумма',
                    dataIndex: 'amount',
                    key: 'amount',
                    render: (value: number) => value.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' }),
                  },
                ]}
                dataSource={selectedPayment.splits}
                rowKey="id"
                pagination={false}
                size="small"
              />
            ) : (
              <p>Распределение отсутствует</p>
            )}
          </>
        )}
      </Drawer>

      {/* Create Modal */}
      <Modal
        title="Зарегистрировать платеж"
        open={modalOpen}
        onOk={handleSave}
        onCancel={() => setModalOpen(false)}
        width={700}
      >
        <Form form={form} layout="vertical">
          <Form.Item name="member_id" label="Член СНТ" rules={[{ required: true }]}>
            <Select
              showSearch
              placeholder="Выберите члена СНТ"
              optionFilterProp="children"
              filterOption={(input, option) =>
                (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
              }
              options={members.map(m => ({ value: m.id, label: m.full_name }))}
              onChange={handleMemberChange}
            />
          </Form.Item>

          <Form.Item name="payment_date" label="Дата платежа" rules={[{ required: true }]}>
            <DatePicker style={{ width: '100%' }} format="DD.MM.YYYY" />
          </Form.Item>

          <Form.Item name="payment_method" label="Способ оплаты" initialValue="cash">
            <Select>
              <Select.Option value="cash">Наличные</Select.Option>
              <Select.Option value="bank_transfer">Банковский перевод</Select.Option>
              <Select.Option value="card">Карта</Select.Option>
            </Select>
          </Form.Item>

          <Divider>Распределение по начислениям</Divider>

          {accruals.length > 0 ? (
            <Form.List name="splits">
              {(fields, { add, remove }) => (
                <>
                  {fields.map(({ key, name, ...restField }) => (
                    <Space key={key} style={{ display: 'flex', marginBottom: 8 }} align="baseline">
                      <Form.Item
                        {...restField}
                        name={[name, 'accrual_id']}
                        rules={[{ required: true, message: 'Выберите начисление' }]}
                      >
                        <Select
                          style={{ width: 300 }}
                          placeholder="Начисление"
                          options={accruals.map(a => ({
                            value: a.id,
                            label: `${a.fee_type_name} ${a.year} - ${a.remaining_amount} ₽`,
                          }))}
                        />
                      </Form.Item>
                      <Form.Item
                        {...restField}
                        name={[name, 'amount']}
                        rules={[{ required: true, message: 'Введите сумму' }]}
                      >
                        <InputNumber placeholder="Сумма" min={0} step={0.01} />
                      </Form.Item>
                      <Button type="link" danger onClick={() => remove(name)}>Удалить</Button>
                    </Space>
                  ))}
                  <Form.Item>
                    <Button type="dashed" onClick={() => add()} block icon={<PlusOutlined />}>
                      Добавить распределение
                    </Button>
                  </Form.Item>
                </>
              )}
            </Form.List>
          ) : (
            <p style={{ color: '#999' }}>
              {form.getFieldValue('member_id') 
                ? 'Нет доступных начислений для этого члена СНТ'
                : 'Выберите члена СНТ для загрузки начислений'}
            </p>
          )}

          <Form.Item name="comment" label="Комментарий">
            <TextArea rows={2} />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default Payments;
