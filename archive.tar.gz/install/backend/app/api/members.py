"""
Members API endpoints
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import Optional, List

from app.db.database import get_db
from app.api.auth import get_current_user
from app.services import MemberService, PlotService, MemberDebt
from app.schemas import (
    MemberCreate, MemberUpdate, MemberResponse, MemberListItem, MemberDetail,
    UserResponse, MemberStatusEnum
)
from app.models import Member

router = APIRouter(prefix="/members", tags=["Members"])


@router.get("", response_model=List[MemberListItem])
def get_members(
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    search: Optional[str] = None,
    status: Optional[MemberStatusEnum] = None,
    has_debt: Optional[bool] = None,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Get all members with filtering and pagination."""
    members, total = MemberService.get_all(
        db, skip=skip, limit=limit, search=search, status=status, has_debt=has_debt
    )
    
    # Enrich with plot count and debt info
    result = []
    for member in members:
        plot_count = len(member.plots)
        debt_info = db.query(MemberDebt).filter(MemberDebt.member_id == member.id).first()
        total_debt = float(debt_info.total_debt) if debt_info else 0.0
        
        item = MemberListItem(
            id=member.id,
            first_name=member.first_name,
            last_name=member.last_name,
            middle_name=member.middle_name,
            birth_date=member.birth_date,
            phone=member.phone,
            email=member.email,
            address=member.address,
            membership_start_date=member.membership_start_date,
            membership_end_date=member.membership_end_date,
            status=member.status,
            status_comment=member.status_comment,
            full_name=member.full_name,
            has_debt=member.has_debt,
            plot_count=plot_count,
            total_debt=total_debt,
            created_at=member.created_at
        )
        result.append(item)
    
    return result


@router.get("/{member_id}", response_model=MemberDetail)
def get_member(
    member_id: int,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Get member by ID."""
    member = MemberService.get_by_id(db, member_id)
    if not member:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Member not found"
        )
    
    # Get debt info
    debt_info = db.query(MemberDebt).filter(MemberDebt.member_id == member.id).first()
    total_debt = float(debt_info.total_debt) if debt_info else 0.0
    debt_category = debt_info.debt_category.value if debt_info and debt_info.debt_category else None
    
    # Get plots
    plots = []
    for mp in member.plots:
        plots.append({
            "id": mp.plot.id,
            "plot_number": mp.plot.plot_number,
            "alley": mp.plot.alley,
            "cadastral_number": mp.plot.cadastral_number,
            "area": float(mp.plot.area),
            "ownership_share": float(mp.ownership_share)
        })
    
    return MemberDetail(
        id=member.id,
        first_name=member.first_name,
        last_name=member.last_name,
        middle_name=member.middle_name,
        birth_date=member.birth_date,
        phone=member.phone,
        email=member.email,
        address=member.address,
        membership_start_date=member.membership_start_date,
        membership_end_date=member.membership_end_date,
        status=member.status,
        status_comment=member.status_comment,
        full_name=member.full_name,
        has_debt=member.has_debt,
        created_at=member.created_at,
        updated_at=member.updated_at,
        plots=plots,
        total_debt=total_debt,
        debt_category=debt_category
    )


@router.post("", response_model=MemberResponse, status_code=status.HTTP_201_CREATED)
def create_member(
    member: MemberCreate,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Create a new member."""
    # Validate plot IDs if provided
    if member.plot_ids:
        for plot_id in member.plot_ids:
            plot = PlotService.get_by_id(db, plot_id)
            if not plot:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Plot with ID {plot_id} not found"
                )
    
    return MemberService.create(db, member)


@router.put("/{member_id}", response_model=MemberResponse)
def update_member(
    member_id: int,
    member_update: MemberUpdate,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Update a member."""
    member = MemberService.get_by_id(db, member_id)
    if not member:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Member not found"
        )
    
    # Validate plot IDs if provided
    if member_update.plot_ids:
        for plot_id in member_update.plot_ids:
            plot = PlotService.get_by_id(db, plot_id)
            if not plot:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Plot with ID {plot_id} not found"
                )
    
    return MemberService.update(db, member, member_update)


@router.delete("/{member_id}")
def delete_member(
    member_id: int,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Delete a member."""
    member = MemberService.get_by_id(db, member_id)
    if not member:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Member not found"
        )
    
    MemberService.delete(db, member)
    return {"message": "Member deleted successfully"}
