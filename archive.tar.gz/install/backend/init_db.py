#!/usr/bin/env python3
"""
Database initialization script
Creates database and default admin user
"""
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import create_engine, text
from app.core.config import settings
from app.core.security import get_password_hash
from app.db.database import Base, engine, SessionLocal
from app.models import User, UserRole, FeeTypeModel, FeeType

def create_database():
    """Create database if it doesn't exist."""
    # Connect without database
    temp_engine = create_engine(
        f"mysql+pymysql://{settings.DB_USER}:{settings.DB_PASSWORD}@{settings.DB_HOST}:{settings.DB_PORT}/"
    )
    
    with temp_engine.connect() as conn:
        conn.execute(text(f"CREATE DATABASE IF NOT EXISTS {settings.DB_NAME} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"))
        conn.commit()
    
    print(f"Database '{settings.DB_NAME}' created or already exists")


def create_tables():
    """Create all tables."""
    Base.metadata.create_all(bind=engine)
    print("All tables created successfully")


def create_admin_user():
    """Create default admin user."""
    db = SessionLocal()
    try:
        # Check if admin exists
        admin = db.query(User).filter(User.username == "admin").first()
        if admin:
            print("Admin user already exists")
            return
        
        # Create admin user
        admin = User(
            username="admin",
            email="admin@snt-monolit.ru",
            full_name="Администратор Системы",
            role=UserRole.ADMIN,
            hashed_password=get_password_hash("admin123"),
            is_active=True
        )
        db.add(admin)
        db.commit()
        print("Admin user created:")
        print("  Username: admin")
        print("  Password: admin123")
        print("  Email: admin@snt-monolit.ru")
    finally:
        db.close()


def create_default_fee_types():
    """Create default fee types."""
    db = SessionLocal()
    try:
        defaults = [
            {"name": "Членские взносы", "code": FeeType.MEMBER, "description": "Ежегодные членские взносы на текущую деятельность"},
            {"name": "Целевые взносы", "code": FeeType.TARGET, "description": "Взносы на конкретные цели (дороги, электричество и т.д.)"},
            {"name": "Электроэнергия", "code": FeeType.ELECTRICITY, "description": "Оплата электроэнергии"},
        ]
        
        for item in defaults:
            existing = db.query(FeeTypeModel).filter(FeeTypeModel.code == item["code"]).first()
            if not existing:
                fee_type = FeeTypeModel(
                    name=item["name"],
                    code=item["code"],
                    description=item["description"],
                    is_active=True
                )
                db.add(fee_type)
        
        db.commit()
        print("Default fee types created")
    finally:
        db.close()


def main():
    """Main initialization function."""
    print("=" * 50)
    print("SNT Monolit Database Initialization")
    print("=" * 50)
    
    try:
        create_database()
        create_tables()
        create_admin_user()
        create_default_fee_types()
        
        print("=" * 50)
        print("Initialization completed successfully!")
        print("=" * 50)
    except Exception as e:
        print(f"Error during initialization: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
