"""
Services for business logic
"""
from sqlalchemy.orm import Session
from sqlalchemy import func, and_, extract
from datetime import datetime, date
from decimal import Decimal
from typing import Optional, List, Tuple

from app.models import (
    User, Member, Plot, MemberPlot, OwnershipHistory,
    FeeTypeModel, FeeRate, FeeAccrual, FeePayment, PaymentSplit,
    MemberDebt, Receipt, ActionLog,
    MemberStatus, PlotStatus, DebtCategory, OwnershipType, FeeType, PaymentMethod
)
from app.schemas import (
    UserCreate, UserUpdate,
    MemberCreate, MemberUpdate,
    PlotCreate, PlotUpdate,
    OwnershipHistoryCreate,
    FeeTypeCreate, FeeTypeUpdate,
    FeeRateCreate, FeeRateUpdate,
    FeeAccrualCreate, FeeAccrualUpdate,
    FeePaymentCreate, FeePaymentUpdate,
    PaymentSplitCreate,
    DashboardStats, ChartDataPoint,
)


# ============================================
# User Service
# ============================================
class UserService:
    @staticmethod
    def get_by_id(db: Session, user_id: int) -> Optional[User]:
        return db.query(User).filter(User.id == user_id).first()

    @staticmethod
    def get_by_username(db: Session, username: str) -> Optional[User]:
        return db.query(User).filter(User.username == username).first()

    @staticmethod
    def get_by_email(db: Session, email: str) -> Optional[User]:
        return db.query(User).filter(User.email == email).first()

    @staticmethod
    def get_all(db: Session, skip: int = 0, limit: int = 100) -> List[User]:
        return db.query(User).offset(skip).limit(limit).all()

    @staticmethod
    def create(db: Session, user: UserCreate, hashed_password: str) -> User:
        db_user = User(
            username=user.username,
            email=user.email,
            full_name=user.full_name,
            role=user.role,
            hashed_password=hashed_password,
        )
        db.add(db_user)
        db.commit()
        db.refresh(db_user)
        return db_user

    @staticmethod
    def update(db: Session, user: User, user_update: UserUpdate) -> User:
        update_data = user_update.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(user, field, value)
        db.commit()
        db.refresh(user)
        return user


# ============================================
# Member Service
# ============================================
class MemberService:
    @staticmethod
    def get_by_id(db: Session, member_id: int) -> Optional[Member]:
        return db.query(Member).filter(Member.id == member_id).first()

    @staticmethod
    def get_all(
        db: Session,
        skip: int = 0,
        limit: int = 100,
        search: Optional[str] = None,
        status: Optional[MemberStatus] = None,
        has_debt: Optional[bool] = None,
    ) -> Tuple[List[Member], int]:
        query = db.query(Member)

        if search:
            search_filter = f"%{search}%"
            query = query.filter(
                and_(
                    Member.last_name.like(search_filter) |
                    Member.first_name.like(search_filter) |
                    Member.middle_name.like(search_filter) |
                    Member.phone.like(search_filter)
                )
            )

        if status:
            query = query.filter(Member.status == status)

        total = query.count()

        if has_debt is True:
            query = query.filter(Member.status == MemberStatus.DEBTOR)

        members = query.offset(skip).limit(limit).all()
        return members, total

    @staticmethod
    def create(db: Session, member: MemberCreate) -> Member:
        plot_ids = member.plot_ids or []
        member_data = member.model_dump(exclude={"plot_ids"})
        
        db_member = Member(**member_data)
        db.add(db_member)
        db.flush()

        # Link plots
        for plot_id in plot_ids:
            member_plot = MemberPlot(member_id=db_member.id, plot_id=plot_id)
            db.add(member_plot)

        db.commit()
        db.refresh(db_member)
        return db_member

    @staticmethod
    def update(db: Session, member: Member, member_update: MemberUpdate) -> Member:
        plot_ids = member_update.plot_ids
        update_data = member_update.model_dump(exclude_unset=True, exclude={"plot_ids"})
        
        for field, value in update_data.items():
            setattr(member, field, value)

        # Update plots if provided
        if plot_ids is not None:
            db.query(MemberPlot).filter(MemberPlot.member_id == member.id).delete()
            for plot_id in plot_ids:
                member_plot = MemberPlot(member_id=member.id, plot_id=plot_id)
                db.add(member_plot)

        db.commit()
        db.refresh(member)
        return member

    @staticmethod
    def delete(db: Session, member: Member) -> None:
        db.delete(member)
        db.commit()

    @staticmethod
    def update_debt_status(db: Session, member: Member) -> None:
        """Update member's debt status based on their accruals and payments."""
        total_debt = db.query(
            func.sum(FeeAccrual.amount - FeeAccrual.paid_amount)
        ).filter(
            FeeAccrual.member_id == member.id,
            FeeAccrual.is_paid == False
        ).scalar() or 0

        # Update or create debt record
        debt_record = db.query(MemberDebt).filter(MemberDebt.member_id == member.id).first()
        
        if total_debt > 0:
            if total_debt < 1000:
                category = DebtCategory.SMALL
            elif total_debt <= 5000:
                category = DebtCategory.MEDIUM
            else:
                category = DebtCategory.LARGE
            
            member.status = MemberStatus.DEBTOR
            
            if debt_record:
                debt_record.total_debt = total_debt
                debt_record.debt_category = category
                debt_record.last_updated = func.now()
            else:
                debt_record = MemberDebt(
                    member_id=member.id,
                    total_debt=total_debt,
                    debt_category=category
                )
                db.add(debt_record)
        else:
            if member.status == MemberStatus.DEBTOR:
                member.status = MemberStatus.ACTIVE
            
            if debt_record:
                db.delete(debt_record)

        db.commit()


# ============================================
# Plot Service
# ============================================
class PlotService:
    @staticmethod
    def get_by_id(db: Session, plot_id: int) -> Optional[Plot]:
        return db.query(Plot).filter(Plot.id == plot_id).first()

    @staticmethod
    def get_all(
        db: Session,
        skip: int = 0,
        limit: int = 100,
        search: Optional[str] = None,
        status: Optional[PlotStatus] = None,
    ) -> Tuple[List[Plot], int]:
        query = db.query(Plot)

        if search:
            search_filter = f"%{search}%"
            query = query.filter(
                Plot.plot_number.like(search_filter) |
                Plot.alley.like(search_filter) |
                Plot.cadastral_number.like(search_filter)
            )

        if status:
            query = query.filter(Plot.status == status)

        total = query.count()
        plots = query.offset(skip).limit(limit).all()
        return plots, total

    @staticmethod
    def create(db: Session, plot: PlotCreate) -> Plot:
        member_ids = plot.member_ids or []
        plot_data = plot.model_dump(exclude={"member_ids"})
        
        db_plot = Plot(**plot_data)
        db.add(db_plot)
        db.flush()

        # Link members
        for member_id in member_ids:
            member_plot = MemberPlot(member_id=member_id, plot_id=db_plot.id)
            db.add(member_plot)

        db.commit()
        db.refresh(db_plot)
        return db_plot

    @staticmethod
    def update(db: Session, plot: Plot, plot_update: PlotUpdate) -> Plot:
        member_ids = plot_update.member_ids
        update_data = plot_update.model_dump(exclude_unset=True, exclude={"member_ids"})
        
        for field, value in update_data.items():
            setattr(plot, field, value)

        # Update members if provided
        if member_ids is not None:
            db.query(MemberPlot).filter(MemberPlot.plot_id == plot.id).delete()
            for member_id in member_ids:
                member_plot = MemberPlot(member_id=member_id, plot_id=plot.id)
                db.add(member_plot)

        db.commit()
        db.refresh(plot)
        return plot

    @staticmethod
    def delete(db: Session, plot: Plot) -> None:
        db.delete(plot)
        db.commit()


# ============================================
# Ownership History Service
# ============================================
class OwnershipHistoryService:
    @staticmethod
    def get_by_plot(db: Session, plot_id: int) -> List[OwnershipHistory]:
        return db.query(OwnershipHistory).filter(
            OwnershipHistory.plot_id == plot_id
        ).order_by(OwnershipHistory.transfer_date.desc()).all()

    @staticmethod
    def create(db: Session, history: OwnershipHistoryCreate) -> OwnershipHistory:
        db_history = OwnershipHistory(**history.model_dump())
        db.add(db_history)
        db.commit()
        db.refresh(db_history)
        return db_history


# ============================================
# Fee Type Service
# ============================================
class FeeTypeService:
    @staticmethod
    def get_by_id(db: Session, fee_type_id: int) -> Optional[FeeTypeModel]:
        return db.query(FeeTypeModel).filter(FeeTypeModel.id == fee_type_id).first()

    @staticmethod
    def get_all(db: Session, active_only: bool = True) -> List[FeeTypeModel]:
        query = db.query(FeeTypeModel)
        if active_only:
            query = query.filter(FeeTypeModel.is_active == True)
        return query.all()

    @staticmethod
    def create(db: Session, fee_type: FeeTypeCreate) -> FeeTypeModel:
        db_fee_type = FeeTypeModel(**fee_type.model_dump())
        db.add(db_fee_type)
        db.commit()
        db.refresh(db_fee_type)
        return db_fee_type

    @staticmethod
    def update(db: Session, fee_type: FeeTypeModel, fee_type_update: FeeTypeUpdate) -> FeeTypeModel:
        update_data = fee_type_update.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(fee_type, field, value)
        db.commit()
        db.refresh(fee_type)
        return fee_type


# ============================================
# Fee Rate Service
# ============================================
class FeeRateService:
    @staticmethod
    def get_by_fee_type_and_year(db: Session, fee_type_id: int, year: int) -> Optional[FeeRate]:
        return db.query(FeeRate).filter(
            FeeRate.fee_type_id == fee_type_id,
            FeeRate.year == year
        ).first()

    @staticmethod
    def get_by_year(db: Session, year: int) -> List[FeeRate]:
        return db.query(FeeRate).filter(FeeRate.year == year).all()

    @staticmethod
    def create(db: Session, fee_rate: FeeRateCreate) -> FeeRate:
        # Check if rate already exists for this fee_type and year
        existing = FeeRateService.get_by_fee_type_and_year(
            db, fee_rate.fee_type_id, fee_rate.year
        )
        if existing:
            existing.rate = fee_rate.rate
            existing.unit = fee_rate.unit
            db.commit()
            db.refresh(existing)
            return existing

        db_fee_rate = FeeRate(**fee_rate.model_dump())
        db.add(db_fee_rate)
        db.commit()
        db.refresh(db_fee_rate)
        return db_fee_rate


# ============================================
# Fee Accrual Service
# ============================================
class FeeAccrualService:
    @staticmethod
    def get_by_id(db: Session, accrual_id: int) -> Optional[FeeAccrual]:
        return db.query(FeeAccrual).filter(FeeAccrual.id == accrual_id).first()

    @staticmethod
    def get_by_member(db: Session, member_id: int, year: Optional[int] = None) -> List[FeeAccrual]:
        query = db.query(FeeAccrual).filter(FeeAccrual.member_id == member_id)
        if year:
            query = query.filter(FeeAccrual.year == year)
        return query.all()

    @staticmethod
    def get_by_year(db: Session, year: int) -> List[FeeAccrual]:
        return db.query(FeeAccrual).filter(FeeAccrual.year == year).all()

    @staticmethod
    def create(db: Session, accrual: FeeAccrualCreate) -> FeeAccrual:
        db_accrual = FeeAccrual(**accrual.model_dump())
        db.add(db_accrual)
        db.commit()
        db.refresh(db_accrual)
        return db_accrual

    @staticmethod
    def create_for_all_members(
        db: Session,
        fee_type_id: int,
        year: int,
        rate_per_sotka: float,
        due_date: date
    ) -> List[FeeAccrual]:
        """Create accruals for all active members based on their plot area."""
        accruals = []
        members = db.query(Member).filter(
            Member.status.in_([MemberStatus.ACTIVE, MemberStatus.DEBTOR])
        ).all()

        for member in members:
            # Calculate total area for member's plots
            total_area = db.query(
                func.sum(Plot.area)
            ).join(
                MemberPlot, MemberPlot.plot_id == Plot.id
            ).filter(
                MemberPlot.member_id == member.id
            ).scalar() or 0

            amount = float(total_area) * rate_per_sotka

            # Check if accrual already exists
            existing = db.query(FeeAccrual).filter(
                FeeAccrual.member_id == member.id,
                FeeAccrual.fee_type_id == fee_type_id,
                FeeAccrual.year == year
            ).first()

            if not existing:
                accrual = FeeAccrual(
                    member_id=member.id,
                    fee_type_id=fee_type_id,
                    year=year,
                    amount=amount,
                    paid_amount=0,
                    is_paid=False,
                    due_date=due_date
                )
                db.add(accrual)
                accruals.append(accrual)

        db.commit()
        return accruals

    @staticmethod
    def update(db: Session, accrual: FeeAccrual, accrual_update: FeeAccrualUpdate) -> FeeAccrual:
        update_data = accrual_update.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(accrual, field, value)
        db.commit()
        db.refresh(accrual)
        return accrual


# ============================================
# Payment Service
# ============================================
class PaymentService:
    @staticmethod
    def get_by_id(db: Session, payment_id: int) -> Optional[FeePayment]:
        return db.query(FeePayment).filter(FeePayment.id == payment_id).first()

    @staticmethod
    def get_by_member(db: Session, member_id: int) -> List[FeePayment]:
        return db.query(FeePayment).filter(
            FeePayment.member_id == member_id
        ).order_by(FeePayment.payment_date.desc()).all()

    @staticmethod
    def get_recent(db: Session, limit: int = 10) -> List[FeePayment]:
        return db.query(FeePayment).order_by(
            FeePayment.payment_date.desc()
        ).limit(limit).all()

    @staticmethod
    def create(db: Session, payment: FeePaymentCreate, created_by: Optional[int] = None) -> FeePayment:
        # Generate receipt number
        today = datetime.now().strftime("%Y%m%d")
        last_payment = db.query(FeePayment).order_by(FeePayment.id.desc()).first()
        next_id = (last_payment.id + 1) if last_payment else 1
        receipt_number = f"KB-{next_id}-{today}"

        db_payment = FeePayment(
            member_id=payment.member_id,
            amount=payment.amount,
            payment_date=payment.payment_date,
            payment_method=payment.payment_method,
            comment=payment.comment,
            receipt_number=receipt_number,
            created_by=created_by
        )
        db.add(db_payment)
        db.flush()

        # Process splits
        remaining = float(payment.amount)
        for split in payment.splits:
            accrual = db.query(FeeAccrual).filter(FeeAccrual.id == split.accrual_id).first()
            if accrual:
                split_amount = min(split.amount, remaining, accrual.remaining_amount)
                if split_amount > 0:
                    payment_split = PaymentSplit(
                        payment_id=db_payment.id,
                        accrual_id=split.accrual_id,
                        amount=split_amount
                    )
                    db.add(payment_split)
                    
                    # Update accrual
                    accrual.paid_amount = float(accrual.paid_amount) + split_amount
                    if accrual.paid_amount >= accrual.amount:
                        accrual.is_paid = True
                    
                    remaining -= split_amount

        db.commit()
        db.refresh(db_payment)

        # Update member debt status
        member = db.query(Member).filter(Member.id == payment.member_id).first()
        if member:
            MemberService.update_debt_status(db, member)

        return db_payment

    @staticmethod
    def generate_receipt_number(db: Session) -> str:
        today = datetime.now().strftime("%Y%m%d")
        last_payment = db.query(FeePayment).order_by(FeePayment.id.desc()).first()
        next_id = (last_payment.id + 1) if last_payment else 1
        return f"KB-{next_id}-{today}"


# ============================================
# Dashboard Service
# ============================================
class DashboardService:
    @staticmethod
    def get_stats(db: Session) -> DashboardStats:
        total_members = db.query(Member).count()
        active_members = db.query(Member).filter(Member.status == MemberStatus.ACTIVE).count()
        debtors_count = db.query(Member).filter(Member.status == MemberStatus.DEBTOR).count()
        plots_count = db.query(Plot).filter(Plot.status == PlotStatus.ACTIVE).count()

        # Total debt
        total_debt_result = db.query(
            func.sum(FeeAccrual.amount - FeeAccrual.paid_amount)
        ).filter(FeeAccrual.is_paid == False).scalar() or 0

        # Total collected
        total_collected_result = db.query(
            func.sum(FeePayment.amount)
        ).scalar() or 0

        return DashboardStats(
            total_members=total_members,
            active_members=active_members,
            debtors_count=debtors_count,
            total_debt=float(total_debt_result),
            total_collected=float(total_collected_result),
            plots_count=plots_count
        )

    @staticmethod
    def get_member_status_chart(db: Session) -> List[ChartDataPoint]:
        statuses = db.query(
            Member.status, func.count(Member.id)
        ).group_by(Member.status).all()

        status_labels = {
            MemberStatus.ACTIVE: "Действительные",
            MemberStatus.DEBTOR: "Должники",
            MemberStatus.FORMER: "Бывшие",
            MemberStatus.DECEASED: "Умершие"
        }

        return [
            ChartDataPoint(label=status_labels.get(status, status), value=count)
            for status, count in statuses
        ]

    @staticmethod
    def get_monthly_income(db: Session, year: int) -> List[ChartDataPoint]:
        results = db.query(
            extract("month", FeePayment.payment_date).label("month"),
            func.sum(FeePayment.amount)
        ).filter(
            extract("year", FeePayment.payment_date) == year
        ).group_by(
            "month"
        ).order_by("month").all()

        month_names = [
            "Янв", "Фев", "Мар", "Апр", "Май", "Июн",
            "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"
        ]

        return [
            ChartDataPoint(label=month_names[month - 1], value=float(amount or 0))
            for month, amount in results
        ]

    @staticmethod
    def get_top_debtors(db: Session, limit: int = 5) -> List[Member]:
        return db.query(Member).filter(
            Member.status == MemberStatus.DEBTOR
        ).limit(limit).all()

    @staticmethod
    def get_recent_payments(db: Session, limit: int = 10) -> List[FeePayment]:
        return db.query(FeePayment).order_by(
            FeePayment.payment_date.desc()
        ).limit(limit).all()


# ============================================
# Action Log Service
# ============================================
class ActionLogService:
    @staticmethod
    def log(
        db: Session,
        user_id: Optional[int],
        action: str,
        entity_type: Optional[str] = None,
        entity_id: Optional[int] = None,
        old_values: Optional[dict] = None,
        new_values: Optional[dict] = None
    ) -> ActionLog:
        import json
        log_entry = ActionLog(
            user_id=user_id,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            old_values=json.dumps(old_values) if old_values else None,
            new_values=json.dumps(new_values) if new_values else None
        )
        db.add(log_entry)
        db.commit()
        db.refresh(log_entry)
        return log_entry
