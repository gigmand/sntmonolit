"""
Dashboard and Reports API endpoints
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import date

from app.db.database import get_db
from app.api.auth import get_current_user
from app.services import DashboardService, MemberService, PaymentService
from app.schemas import (
    DashboardResponse, DashboardStats, ChartDataPoint,
    MemberListItem, FeePaymentResponse,
    UserResponse, MemberStatusEnum
)
from app.models import Member, FeePayment

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


@router.get("", response_model=DashboardResponse)
def get_dashboard(
    year: int = Query(default_factory=lambda: date.today().year),
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Get dashboard with key statistics and charts."""
    stats = DashboardService.get_stats(db)
    member_status_chart = DashboardService.get_member_status_chart(db)
    monthly_income = DashboardService.get_monthly_income(db, year)
    
    # Get top debtors
    top_debtors_data = []
    for member in DashboardService.get_top_debtors(db, limit=5):
        debt_info = db.query(
            lambda: None  # placeholder - will get debt from MemberDebt
        )
        from app.models import MemberDebt
        debt = db.query(MemberDebt).filter(MemberDebt.member_id == member.id).first()
        total_debt = float(debt.total_debt) if debt else 0.0
        
        top_debtors_data.append({
            "id": member.id,
            "first_name": member.first_name,
            "last_name": member.last_name,
            "middle_name": member.middle_name,
            "birth_date": member.birth_date,
            "phone": member.phone,
            "email": member.email,
            "address": member.address,
            "membership_start_date": member.membership_start_date,
            "membership_end_date": member.membership_end_date,
            "status": member.status,
            "status_comment": member.status_comment,
            "full_name": member.full_name,
            "has_debt": member.has_debt,
            "plot_count": len(member.plots),
            "total_debt": total_debt,
            "created_at": member.created_at
        })
    
    # Get recent payments
    recent_payments_data = []
    for payment in DashboardService.get_recent_payments(db, limit=10):
        recent_payments_data.append({
            "id": payment.id,
            "member_id": payment.member_id,
            "amount": float(payment.amount),
            "payment_date": payment.payment_date,
            "payment_method": payment.payment_method.value,
            "comment": payment.comment,
            "receipt_number": payment.receipt_number,
            "receipt_generated": payment.receipt_generated,
            "member_name": payment.member.full_name,
            "created_at": payment.created_at,
            "created_by": payment.created_by
        })
    
    return {
        "stats": stats,
        "member_status_chart": member_status_chart,
        "monthly_income": monthly_income,
        "top_debtors": top_debtors_data,
        "recent_payments": recent_payments_data
    }


@router.get("/stats", response_model=DashboardStats)
def get_stats(
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Get only the statistics."""
    return DashboardService.get_stats(db)


@router.get("/members/chart", response_model=List[ChartDataPoint])
def get_members_chart(
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Get member status distribution chart data."""
    return DashboardService.get_member_status_chart(db)


@router.get("/income/chart", response_model=List[ChartDataPoint])
def get_income_chart(
    year: int = Query(default_factory=lambda: date.today().year),
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Get monthly income chart data."""
    return DashboardService.get_monthly_income(db, year)


@router.get("/debtors/top", response_model=List[MemberListItem])
def get_top_debtors(
    limit: int = Query(5, ge=1, le=20),
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Get top debtors."""
    from app.models import MemberDebt
    
    debtors = DashboardService.get_top_debtors(db, limit)
    result = []
    for member in debtors:
        debt = db.query(MemberDebt).filter(MemberDebt.member_id == member.id).first()
        total_debt = float(debt.total_debt) if debt else 0.0
        
        result.append({
            "id": member.id,
            "first_name": member.first_name,
            "last_name": member.last_name,
            "middle_name": member.middle_name,
            "birth_date": member.birth_date,
            "phone": member.phone,
            "email": member.email,
            "address": member.address,
            "membership_start_date": member.membership_start_date,
            "membership_end_date": member.membership_end_date,
            "status": member.status,
            "status_comment": member.status_comment,
            "full_name": member.full_name,
            "has_debt": member.has_debt,
            "plot_count": len(member.plots),
            "total_debt": total_debt,
            "created_at": member.created_at
        })
    return result


@router.get("/payments/recent", response_model=List[FeePaymentResponse])
def get_recent_payments(
    limit: int = Query(10, ge=1, le=50),
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Get recent payments."""
    payments = PaymentService.get_recent(db, limit)
    
    result = []
    for p in payments:
        result.append({
            "id": p.id,
            "member_id": p.member_id,
            "amount": float(p.amount),
            "payment_date": p.payment_date,
            "payment_method": p.payment_method.value,
            "comment": p.comment,
            "receipt_number": p.receipt_number,
            "receipt_generated": p.receipt_generated,
            "member_name": p.member.full_name,
            "created_at": p.created_at,
            "created_by": p.created_by
        })
    return result


# ============================================
# Reports
# ============================================
@router.get("/reports/debtors")
def get_debtors_report(
    category: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Get debtors report with optional category filter."""
    from app.models import MemberDebt, DebtCategory
    
    query = db.query(Member).join(MemberDebt).filter(
        Member.status == MemberStatusEnum.DEBTOR
    )
    
    if category:
        cat_map = {
            "small": DebtCategory.SMALL,
            "medium": DebtCategory.MEDIUM,
            "large": DebtCategory.LARGE
        }
        if category in cat_map:
            query = query.filter(MemberDebt.debt_category == cat_map[category])
    
    results = []
    for member in query.all():
        debt = db.query(MemberDebt).filter(MemberDebt.member_id == member.id).first()
        results.append({
            "id": member.id,
            "full_name": member.full_name,
            "phone": member.phone,
            "email": member.email,
            "plot_count": len(member.plots),
            "total_debt": float(debt.total_debt) if debt else 0.0,
            "debt_category": debt.debt_category.value if debt and debt.debt_category else None
        })
    
    return results


@router.get("/reports/members")
def get_members_report(
    status: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Get members report."""
    query = db.query(Member)
    
    if status:
        status_map = {
            "active": MemberStatusEnum.ACTIVE,
            "debtor": MemberStatusEnum.DEBTOR,
            "former": MemberStatusEnum.FORMER,
            "deceased": MemberStatusEnum.DECEASED
        }
        if status in status_map:
            query = query.filter(Member.status == status_map[status])
    
    results = []
    for member in query.all():
        results.append({
            "id": member.id,
            "full_name": member.full_name,
            "phone": member.phone,
            "email": member.email,
            "status": member.status.value,
            "membership_start_date": member.membership_start_date,
            "plot_count": len(member.plots)
        })
    
    return results


@router.get("/reports/fees")
def get_fees_report(
    year: int = Query(default_factory=lambda: date.today().year),
    db: Session = Depends(get_db),
    current_user: UserResponse = Depends(get_current_user)
):
    """Get fees report for a year."""
    from app.models import FeeAccrual
    
    accruals = db.query(FeeAccrual).filter(FeeAccrual.year == year).all()
    
    # Group by fee type
    by_type = {}
    for a in accruals:
        type_name = a.fee_type.name
        if type_name not in by_type:
            by_type[type_name] = {"accruals": 0, "paid": 0, "remaining": 0}
        by_type[type_name]["accruals"] += float(a.amount)
        by_type[type_name]["paid"] += float(a.paid_amount)
        by_type[type_name]["remaining"] += a.remaining_amount
    
    return {
        "year": year,
        "total_accruals": sum(v["accruals"] for v in by_type.values()),
        "total_paid": sum(v["paid"] for v in by_type.values()),
        "total_remaining": sum(v["remaining"] for v in by_type.values()),
        "by_type": by_type
    }
