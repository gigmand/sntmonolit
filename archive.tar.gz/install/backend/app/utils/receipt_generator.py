"""
PDF Receipt Generator using WeasyPrint
"""
from datetime import datetime
from typing import Optional
from pathlib import Path
from weasyprint import HTML, CSS
from weasyprint.text.fonts import FontConfiguration
import os

from app.core.config import settings


class ReceiptGenerator:
    """Generate PDF receipts for payments."""

    @staticmethod
    def generate_html(
        receipt_number: str,
        payment_date: str,
        member_name: str,
        member_address: str,
        member_phone: str,
        amount: float,
        payment_method: str,
        splits: list,
        comment: Optional[str] = None,
    ) -> str:
        """Generate HTML content for the receipt."""

        payment_method_labels = {
            "cash": "Наличные",
            "bank_transfer": "Банковский перевод",
            "card": "Банковская карта",
        }

        splits_html = ""
        for split in splits:
            splits_html += f"""
            <tr>
                <td style="padding: 8px; border-bottom: 1px solid #ddd;">{split.get('fee_type_name', 'Взнос')}</td>
                <td style="padding: 8px; border-bottom: 1px solid #ddd; text-align: center;">{split.get('year', '')}</td>
                <td style="padding: 8px; border-bottom: 1px solid #ddd; text-align: right;">{split.get('amount', 0):,.2f} ₽</td>
            </tr>
            """

        html = f"""
        <!DOCTYPE html>
        <html lang="ru">
        <head>
            <meta charset="UTF-8">
            <style>
                @page {{
                    size: A4;
                    margin: 2cm;
                }}
                body {{
                    font-family: "DejaVu Sans", Arial, sans-serif;
                    font-size: 12pt;
                    line-height: 1.5;
                    color: #333;
                }}
                .header {{
                    text-align: center;
                    border-bottom: 2px solid #1890ff;
                    padding-bottom: 15px;
                    margin-bottom: 20px;
                }}
                .header h1 {{
                    margin: 0;
                    color: #1890ff;
                    font-size: 18pt;
                }}
                .header p {{
                    margin: 5px 0;
                    color: #666;
                    font-size: 10pt;
                }}
                .receipt-info {{
                    background: #f5f5f5;
                    padding: 15px;
                    border-radius: 5px;
                    margin-bottom: 20px;
                }}
                .receipt-info table {{
                    width: 100%;
                    border-collapse: collapse;
                }}
                .receipt-info td {{
                    padding: 5px 0;
                }}
                .receipt-info td:first-child {{
                    font-weight: bold;
                    width: 150px;
                }}
                .member-info {{
                    margin-bottom: 20px;
                }}
                .member-info h3 {{
                    margin: 0 0 10px 0;
                    color: #1890ff;
                    font-size: 14pt;
                }}
                .splits-table {{
                    width: 100%;
                    border-collapse: collapse;
                    margin-bottom: 20px;
                }}
                .splits-table th {{
                    background: #1890ff;
                    color: white;
                    padding: 10px;
                    text-align: left;
                }}
                .splits-table td {{
                    padding: 8px;
                    border-bottom: 1px solid #ddd;
                }}
                .total-row {{
                    font-weight: bold;
                    font-size: 14pt;
                    background: #e6f7ff;
                }}
                .footer {{
                    margin-top: 40px;
                    padding-top: 20px;
                    border-top: 1px solid #ddd;
                    text-align: center;
                    color: #999;
                    font-size: 9pt;
                }}
                .stamp {{
                    margin-top: 30px;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }}
                .stamp-box {{
                    width: 150px;
                    height: 150px;
                    border: 2px dashed #ccc;
                    border-radius: 10px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    color: #ccc;
                    font-size: 10pt;
                }}
                .signature {{
                    text-align: center;
                }}
                .signature-line {{
                    border-top: 1px solid #333;
                    width: 200px;
                    margin: 5px auto;
                }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>СНТ "МОНОЛИТ"</h1>
                <p>Садоводческое некоммерческое товарищество "МОНОЛИТ"</p>
                <p>644043, Россия, г. Омск, ул. Партизанская, 12</p>
                <p>ИНН/КПП: — / — &nbsp;&nbsp;|&nbsp;&nbsp; ОГРН: —</p>
            </div>

            <div class="receipt-info">
                <table>
                    <tr>
                        <td>Квитанция №:</td>
                        <td><strong>{receipt_number}</strong></td>
                    </tr>
                    <tr>
                        <td>Дата:</td>
                        <td>{datetime.strptime(payment_date, '%Y-%m-%d').strftime('%d.%m.%Y')}</td>
                    </tr>
                    <tr>
                        <td>Способ оплаты:</td>
                        <td>{payment_method_labels.get(payment_method, payment_method)}</td>
                    </tr>
                </table>
            </div>

            <div class="member-info">
                <h3>Плательщик</h3>
                <p><strong>ФИО:</strong> {member_name}</p>
                <p><strong>Адрес:</strong> {member_address or '—'}</p>
                <p><strong>Телефон:</strong> {member_phone or '—'}</p>
            </div>

            <h3 style="color: #1890ff; margin-bottom: 10px;">Распределение платежа</h3>
            <table class="splits-table">
                <thead>
                    <tr>
                        <th style="width: 50%;">Назначение</th>
                        <th style="width: 20%; text-align: center;">Период</th>
                        <th style="width: 30%; text-align: right;">Сумма</th>
                    </tr>
                </thead>
                <tbody>
                    {splits_html}
                    <tr class="total-row">
                        <td colspan="2" style="padding: 10px;">ИТОГО:</td>
                        <td style="padding: 10px; text-align: right;">{amount:,.2f} ₽</td>
                    </tr>
                </tbody>
            </table>

            {f'<p><strong>Комментарий:</strong> {comment}</p>' if comment else ''}

            <div class="stamp">
                <div class="stamp-box">
                    М.П.
                </div>
                <div class="signature">
                    <p>Кассир</p>
                    <div class="signature-line"></div>
                    <p style="font-size: 9pt; color: #999;">(подпись)</p>
                </div>
            </div>

            <div class="footer">
                <p>Квитанция сформирована автоматически {datetime.now().strftime('%d.%m.%Y %H:%M')}</p>
                <p>СНТ "Монолит" | snt-monolit@yandex.ru | 8 950 339 6939</p>
            </div>
        </body>
        </html>
        """
        return html

    @staticmethod
    def generate_pdf(
        output_path: str,
        receipt_number: str,
        payment_date: str,
        member_name: str,
        member_address: Optional[str] = None,
        member_phone: Optional[str] = None,
        amount: float = 0.0,
        payment_method: str = "cash",
        splits: Optional[list] = None,
        comment: Optional[str] = None,
    ) -> str:
        """Generate PDF receipt and save to file."""

        html_content = ReceiptGenerator.generate_html(
            receipt_number=receipt_number,
            payment_date=payment_date,
            member_name=member_name,
            member_address=member_address or "",
            member_phone=member_phone or "",
            amount=amount,
            payment_method=payment_method,
            splits=splits or [],
            comment=comment,
        )

        # Create output directory if not exists
        os.makedirs(os.path.dirname(output_path), exist_ok=True)

        # Generate PDF
        font_config = FontConfiguration()
        html = HTML(string=html_content)
        css = CSS(string="""
            @font-face {
                font-family: "DejaVu Sans";
                src: url("file:///usr/share/fonts/truetype/dejavu/DejaVuSans.ttf");
            }
        """, font_config=font_config)

        html.write_pdf(output_path, stylesheets=[css])

        return output_path

    @staticmethod
    def generate_html_dual(
        payments_data: list
    ) -> str:
        """
        Generate HTML content for 2 identical receipts on one A4 page.
        First receipt is original, second is copy.
        Compact version with plots list.
        """
        if len(payments_data) == 0:
            return ""
        
        p = payments_data[0]  # Single payment
        
        def generate_receipt_block(receipt_label):
            # Generate splits HTML
            splits_html = ""
            for split in p.get('splits', []):
                splits_html += f"""
                <tr>
                    <td style="padding: 3px 5px; border-bottom: 1px solid #ddd; font-size: 8pt;">{split.get('fee_type_name', 'Взнос')}</td>
                    <td style="padding: 3px 5px; border-bottom: 1px solid #ddd; text-align: center; font-size: 8pt;">{split.get('year', '')}</td>
                    <td style="padding: 3px 5px; border-bottom: 1px solid #ddd; text-align: right; font-size: 8pt;">{split.get('amount', 0):,.2f}</td>
                </tr>
                """
            
            # Generate plots HTML if available
            plots_html = ""
            if p.get('plots'):
                plots_list = ", ".join([plot.get('plot_number', '') for plot in p.get('plots', [])])
                plots_html = f"""
                <div style="font-size: 7pt; margin: 3px 0; color: #555;">
                    <strong>Участки:</strong> {plots_list}
                    {f" &nbsp;|&nbsp; <strong>Полив:</strong> {'Есть' if p.get('has_irrigation') else 'Нет'}" : ''}
                </div>
                """
            
            payment_date_formatted = datetime.strptime(p['payment_date'], '%Y-%m-%d').strftime('%d.%m.%Y') if p.get('payment_date') else ''
            
            return f"""
            <div class="receipt-block">
                <div class="header-small">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <strong style="font-size: 10pt;">СНТ "МОНОЛИТ"</strong><br/>
                            <span style="font-size: 6pt;">644043, г. Омск, ул. Партизанская, 12</span><br/>
                            <span style="font-size: 6pt;">snt-monolit@yandex.ru | 8 950 339 6939</span>
                        </div>
                        <div style="font-size: 8pt; font-weight: bold; color: #1890ff;">{receipt_label}</div>
                    </div>
                </div>
                
                <div class="receipt-info-small">
                    <table style="width: 100%; font-size: 7pt;">
                        <tr>
                            <td style="width: 60%;"><strong>Квитанция № {p.get('receipt_number', '')}</strong></td>
                            <td style="width: 40%; text-align: right;">{payment_date_formatted}</td>
                        </tr>
                    </table>
                </div>
                
                <div style="font-size: 8pt; margin: 5px 0;">
                    <strong>Плательщик:</strong> {p.get('member_name', '')}
                </div>
                {plots_html}
                
                <table class="splits-table-small">
                    <thead>
                        <tr>
                            <th style="width: 55%; font-size: 7pt;">Назначение</th>
                            <th style="width: 20%; text-align: center; font-size: 7pt;">Год</th>
                            <th style="width: 25%; text-align: right; font-size: 7pt;">Сумма</th>
                        </tr>
                    </thead>
                    <tbody>
                        {splits_html}
                        <tr class="total-row-small">
                            <td colspan="2" style="padding: 4px; font-weight: bold; font-size: 8pt;">ИТОГО:</td>
                            <td style="padding: 4px; text-align: right; font-weight: bold; font-size: 8pt;">{p.get('amount', 0):,.2f} ₽</td>
                        </tr>
                    </tbody>
                </table>
                
                <div class="stamp-small">
                    <div style="border: 1px dashed #ccc; width: 50px; height: 50px; display: flex; align-items: center; justify-content: center; color: #ccc; font-size: 7pt; border-radius: 3px;">М.П.</div>
                    <div style="text-align: center; font-size: 7pt;">
                        <div>Кассир</div>
                        <div style="border-top: 1px solid #333; width: 70px; margin: 2px auto;"></div>
                    </div>
                </div>
            </div>
            """
        
        # Generate two identical receipts - original and copy
        receipts_html = generate_receipt_block("ОРИГИНАЛ") + generate_receipt_block("КОПИЯ")
        
        html = f"""
        <!DOCTYPE html>
        <html lang="ru">
        <head>
            <meta charset="UTF-8">
            <style>
                @page {{
                    size: A4;
                    margin: 8mm;
                }}
                @media print {{
                    body {{ -webkit-print-color-adjust: exact; print-color-adjust: exact; }}
                }}
                body {{
                    font-family: "DejaVu Sans", Arial, sans-serif;
                    font-size: 9pt;
                    line-height: 1.2;
                    color: #000;
                    margin: 0;
                    padding: 0;
                }}
                .receipt-block {{
                    border: 1px solid #ccc;
                    border-radius: 3px;
                    padding: 8px;
                    margin: 5px;
                    background: #fff;
                    page-break-inside: avoid;
                }}
                .receipt-block + .receipt-block {{
                    border-top: 2px dashed #999;
                    margin-top: 10px;
                    padding-top: 10px;
                    position: relative;
                }}
                .receipt-block + .receipt-block::before {{
                    content: "✂ Отрезать ✂";
                    position: absolute;
                    top: -8px;
                    left: 50%;
                    transform: translateX(-50%);
                    background: #fff;
                    padding: 0 8px;
                    font-size: 7pt;
                    color: #666;
                }}
                .header-small {{
                    border-bottom: 1px solid #1890ff;
                    padding-bottom: 4px;
                    margin-bottom: 5px;
                }}
                .receipt-info-small {{
                    background: #f5f5f5;
                    padding: 4px 6px;
                    border-radius: 2px;
                    margin-bottom: 5px;
                }}
                .splits-table-small {{
                    width: 100%;
                    border-collapse: collapse;
                    margin-bottom: 5px;
                }}
                .splits-table-small th {{
                    background: #1890ff;
                    color: white;
                    padding: 4px;
                    text-align: left;
                    font-weight: bold;
                }}
                .splits-table-small td {{
                    padding: 3px 5px;
                    border-bottom: 1px solid #ddd;
                }}
                .total-row-small {{
                    background: #e6f7ff;
                }}
                .stamp-small {{
                    margin-top: 5px;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }}
            </style>
        </head>
        <body>
            {receipts_html}
        </body>
        </html>
        """
        return html

    @staticmethod
    def generate_pdf_dual(
        output_path: str,
        payments_data: list,
    ) -> str:
        """
        Generate PDF with 2 identical receipts (original + copy) on one A4 page.
        
        Args:
            output_path: Path to save PDF
            payments_data: List with single payment data dict
        """
        from weasyprint.text.fonts import FontConfiguration
        
        html_content = ReceiptGenerator.generate_html_dual(payments_data)
        
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        font_config = FontConfiguration()
        html = HTML(string=html_content)
        css = CSS(string="""
            @font-face {
                font-family: "DejaVu Sans";
                src: url("file:///usr/share/fonts/truetype/dejavu/DejaVuSans.ttf");
            }
        """, font_config=font_config)
        
        html.write_pdf(output_path, stylesheets=[css])
        
        return output_path


def generate_receipt_for_payment(
    payment: dict,
    member: dict,
    splits_detail: list,
) -> str:
    """
    Generate a receipt PDF for a payment.

    Args:
        payment: Payment data dict
        member: Member data dict
        splits_detail: List of split details with fee_type_name

    Returns:
        Path to generated PDF file
    """
    receipt_number = payment.get('receipt_number', f"KB-{payment.get('id', 0)}")
    output_path = f"{settings.RECEIPTS_DIR}/{receipt_number}.pdf"

    generator = ReceiptGenerator()
    generator.generate_pdf(
        output_path=output_path,
        receipt_number=receipt_number,
        payment_date=payment.get('payment_date', datetime.now().strftime('%Y-%m-%d')),
        member_name=member.get('full_name', ''),
        member_address=member.get('address'),
        member_phone=member.get('phone'),
        amount=float(payment.get('amount', 0)),
        payment_method=payment.get('payment_method', 'cash'),
        splits=splits_detail,
        comment=payment.get('comment'),
    )

    return output_path
