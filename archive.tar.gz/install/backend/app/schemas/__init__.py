"""
Pydantic schemas for request/response validation
"""
from datetime import datetime, date
from typing import Optional, List
from pydantic import BaseModel, Field, EmailStr, ConfigDict
from enum import Enum


# ============================================
# Enums
# ============================================
class UserRoleEnum(str, Enum):
    ADMIN = "admin"
    CHAIRMAN = "chairman"
    TREASURER = "treasurer"
    SECRETARY = "secretary"
    OBSERVER = "observer"


class MemberStatusEnum(str, Enum):
    ACTIVE = "active"
    DEBTOR = "debtor"
    FORMER = "former"
    DECEASED = "deceased"


class PlotStatusEnum(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    ARCHIVED = "archived"


class OwnershipTypeEnum(str, Enum):
    SALE = "sale"
    INHERITANCE = "inheritance"
    GIFT = "gift"
    OTHER = "other"


class FeeTypeEnum(str, Enum):
    MEMBER = "member"
    TARGET = "target"
    ELECTRICITY = "electricity"


class PaymentMethodEnum(str, Enum):
    CASH = "cash"
    BANK_TRANSFER = "bank_transfer"
    CARD = "card"


class DebtCategoryEnum(str, Enum):
    SMALL = "small"
    MEDIUM = "medium"
    LARGE = "large"


# ============================================
# Common schemas
# ============================================
class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    username: Optional[str] = None
    user_id: Optional[int] = None
    role: Optional[str] = None


class Message(BaseModel):
    message: str


# ============================================
# User schemas
# ============================================
class UserBase(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    full_name: str = Field(..., max_length=200)
    role: UserRoleEnum = UserRoleEnum.OBSERVER


class UserCreate(UserBase):
    password: str = Field(..., min_length=6)


class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    full_name: Optional[str] = None
    role: Optional[UserRoleEnum] = None
    is_active: Optional[bool] = None


class UserResponse(UserBase):
    id: int
    is_active: bool
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


# ============================================
# Member schemas
# ============================================
class MemberBase(BaseModel):
    first_name: str = Field(..., max_length=100)
    last_name: str = Field(..., max_length=100)
    middle_name: Optional[str] = Field(None, max_length=100)
    birth_date: Optional[date] = None
    phone: Optional[str] = Field(None, max_length=50)
    email: Optional[EmailStr] = None
    address: Optional[str] = Field(None, max_length=255)
    membership_start_date: Optional[date] = None
    membership_end_date: Optional[date] = None
    status: MemberStatusEnum = MemberStatusEnum.ACTIVE
    status_comment: Optional[str] = None


class MemberCreate(MemberBase):
    plot_ids: Optional[List[int]] = None


class MemberUpdate(MemberBase):
    plot_ids: Optional[List[int]] = None


class MemberResponse(MemberBase):
    id: int
    full_name: str
    has_debt: bool
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class MemberListItem(MemberBase):
    id: int
    full_name: str
    has_debt: bool
    plot_count: int = 0
    total_debt: float = 0.0
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class PlotInfo(BaseModel):
    id: int
    plot_number: str
    alley: Optional[str]
    cadastral_number: Optional[str]
    area: float
    ownership_share: float

    model_config = ConfigDict(from_attributes=True)


class MemberDetail(MemberResponse):
    plots: List["PlotInfo"] = []
    total_debt: float = 0.0
    debt_category: Optional[DebtCategoryEnum] = None


# ============================================
# Plot schemas
# ============================================
class PlotBase(BaseModel):
    plot_number: str = Field(..., max_length=20)
    alley: Optional[str] = Field(None, max_length=100)
    cadastral_number: Optional[str] = Field(None, max_length=50)
    area: float = Field(..., gt=0)
    status: PlotStatusEnum = PlotStatusEnum.ACTIVE


class PlotCreate(PlotBase):
    member_ids: Optional[List[int]] = None


class PlotUpdate(PlotBase):
    member_ids: Optional[List[int]] = None


class PlotResponse(PlotBase):
    id: int
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class PlotListItem(PlotBase):
    id: int
    member_names: List[str] = []
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class MemberInfo(BaseModel):
    id: int
    full_name: str
    ownership_share: float

    model_config = ConfigDict(from_attributes=True)


# ============================================
# Ownership History schemas
# ============================================
class OwnershipHistoryBase(BaseModel):
    member_id: int
    plot_id: int
    transfer_date: date
    transfer_type: OwnershipTypeEnum
    document_number: Optional[str] = Field(None, max_length=100)
    comment: Optional[str] = None


class OwnershipHistoryCreate(OwnershipHistoryBase):
    pass


class OwnershipHistoryItem(OwnershipHistoryBase):
    id: int
    member_name: str
    plot_number: str
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class PlotDetail(PlotResponse):
    members: List[MemberInfo] = []
    ownership_history: List["OwnershipHistoryItem"] = []


# ============================================
# Fee Type schemas
# ============================================
class FeeTypeBase(BaseModel):
    name: str = Field(..., max_length=100)
    code: FeeTypeEnum
    description: Optional[str] = None
    is_active: bool = True


class FeeTypeCreate(FeeTypeBase):
    pass


class FeeTypeUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None


class FeeTypeResponse(FeeTypeBase):
    id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


# ============================================
# Fee Rate schemas
# ============================================
class FeeRateBase(BaseModel):
    fee_type_id: int
    year: int = Field(..., ge=2000, le=2100)
    rate: float = Field(..., ge=0)
    unit: str = "sotka"


class FeeRateCreate(FeeRateBase):
    pass


class FeeRateUpdate(BaseModel):
    rate: Optional[float] = None
    unit: Optional[str] = None


class FeeRateResponse(FeeRateBase):
    id: int
    fee_type_name: str
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


# ============================================
# Fee Accrual schemas
# ============================================
class FeeAccrualBase(BaseModel):
    member_id: int
    fee_type_id: int
    year: int
    amount: float = Field(..., ge=0)
    due_date: Optional[date] = None


class FeeAccrualCreate(FeeAccrualBase):
    pass


class FeeAccrualUpdate(BaseModel):
    amount: Optional[float] = None
    due_date: Optional[date] = None
    is_paid: Optional[bool] = None


class FeeAccrualResponse(FeeAccrualBase):
    id: int
    member_name: str
    fee_type_name: str
    paid_amount: float
    remaining_amount: float
    is_paid: bool
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


# ============================================
# Payment schemas
# ============================================
class PaymentSplitBase(BaseModel):
    accrual_id: int
    amount: float = Field(..., gt=0)


class PaymentSplitCreate(PaymentSplitBase):
    pass


class PaymentSplitResponse(PaymentSplitBase):
    id: int
    payment_id: int

    model_config = ConfigDict(from_attributes=True)


class FeePaymentBase(BaseModel):
    member_id: int
    amount: float = Field(..., gt=0)
    payment_date: date
    payment_method: PaymentMethodEnum = PaymentMethodEnum.CASH
    comment: Optional[str] = None


class FeePaymentCreate(FeePaymentBase):
    splits: List[PaymentSplitCreate] = []


class FeePaymentUpdate(BaseModel):
    comment: Optional[str] = None


class FeePaymentResponse(FeePaymentBase):
    id: int
    member_name: str
    receipt_number: Optional[str] = None
    receipt_generated: bool
    created_at: datetime
    created_by: Optional[int] = None

    model_config = ConfigDict(from_attributes=True)


class FeePaymentDetail(FeePaymentResponse):
    splits: List[PaymentSplitResponse] = []


# ============================================
# Member Debt schemas
# ============================================
class MemberDebtBase(BaseModel):
    member_id: int
    total_debt: float = 0.0
    debt_category: Optional[DebtCategoryEnum] = None


class MemberDebtResponse(MemberDebtBase):
    id: int
    member_name: str
    last_updated: datetime

    model_config = ConfigDict(from_attributes=True)


# ============================================
# Receipt schemas
# ============================================
class ReceiptBase(BaseModel):
    payment_id: int
    receipt_number: str
    file_path: Optional[str] = None


class ReceiptResponse(ReceiptBase):
    id: int
    generated_at: datetime
    generated_by: Optional[int] = None

    model_config = ConfigDict(from_attributes=True)


# ============================================
# Action Log schemas
# ============================================
class ActionLogBase(BaseModel):
    user_id: Optional[int] = None
    action: str
    entity_type: Optional[str] = None
    entity_id: Optional[int] = None


class ActionLogResponse(ActionLogBase):
    id: int
    username: Optional[str] = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


# ============================================
# Dashboard schemas
# ============================================
class DashboardStats(BaseModel):
    total_members: int
    active_members: int
    debtors_count: int
    total_debt: float
    total_collected: float
    plots_count: int


class ChartDataPoint(BaseModel):
    label: str
    value: float


class DashboardResponse(BaseModel):
    stats: DashboardStats
    member_status_chart: List[ChartDataPoint]
    monthly_income: List[ChartDataPoint]
    top_debtors: List[MemberListItem]
    recent_payments: List[FeePaymentResponse]


# ============================================
# Pagination schemas
# ============================================
class PaginationParams(BaseModel):
    page: int = Field(1, ge=1)
    page_size: int = Field(20, ge=1, le=100)
    search: Optional[str] = None
    sort_by: Optional[str] = None
    sort_order: str = "asc"


class PaginationMeta(BaseModel):
    page: int
    page_size: int
    total: int
    total_pages: int


class PaginatedResponse(BaseModel):
    items: List
    meta: PaginationMeta
