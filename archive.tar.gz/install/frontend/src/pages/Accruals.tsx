import React, { useEffect, useState } from 'react';
import {
  Table, Button, Space, Modal, Form, InputNumber, Select,
  DatePicker, message, Tag, Card, Row, Col, Typography, Statistic,
} from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { PlusOutlined, ThunderboltOutlined } from '@ant-design/icons';
import { feesApi, membersApi } from '@/services/api';
import type { FeeAccrual, FeeType, MemberListItem } from '@/types/api';
import dayjs from 'dayjs';

const { Title } = Typography;

const Accruals: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [accruals, setAccruals] = useState<FeeAccrual[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [bulkModalOpen, setBulkModalOpen] = useState(false);
  const [form] = Form.useForm();
  const [bulkForm] = Form.useForm();
  const [feeTypes, setFeeTypes] = useState<FeeType[]>([]);
  const [members, setMembers] = useState<MemberListItem[]>([]);
  const [yearFilter, setYearFilter] = useState<number>(new Date().getFullYear());

  useEffect(() => {
    loadAccruals();
    loadFeeTypes();
    loadMembers();
  }, [yearFilter]);

  const loadAccruals = async () => {
    try {
      setLoading(true);
      const data = await feesApi.getAccruals({ year: yearFilter });
      setAccruals(data);
    } catch (error) {
      message.error('Ошибка загрузки начислений');
    } finally {
      setLoading(false);
    }
  };

  const loadFeeTypes = async () => {
    try {
      const data = await feesApi.getFeeTypes();
      setFeeTypes(data);
    } catch (error) {
      console.error('Failed to load fee types:', error);
    }
  };

  const loadMembers = async () => {
    try {
      const data = await membersApi.getAll({ limit: 100 });
      setMembers(data);
    } catch (error) {
      console.error('Failed to load members:', error);
    }
  };

  const handleCreate = () => {
    form.resetFields();
    setModalOpen(true);
  };

  const handleBulkCreate = () => {
    bulkForm.resetFields();
    bulkForm.setFieldsValue({ year: yearFilter });
    setBulkModalOpen(true);
  };

  const handleSave = async () => {
    try {
      const values = await form.validateFields();
      await feesApi.createAccrual({
        member_id: values.member_id,
        fee_type_id: values.fee_type_id,
        year: values.year,
        amount: values.amount,
        due_date: values.due_date ? values.due_date.format('YYYY-MM-DD') : null,
      });
      message.success('Начисление создано');
      setModalOpen(false);
      loadAccruals();
    } catch (error: any) {
      if (error?.response?.data?.detail) {
        message.error(error.response.data.detail);
      }
    }
  };

  const handleBulkSave = async () => {
    try {
      const values = await bulkForm.validateFields();
      await feesApi.createBulkAccruals({
        fee_type_id: values.fee_type_id,
        year: values.year,
        rate_per_sotka: values.rate_per_sotka,
        due_date: values.due_date.format('YYYY-MM-DD'),
      });
      message.success('Массовые начисления созданы');
      setBulkModalOpen(false);
      loadAccruals();
    } catch (error: any) {
      if (error?.response?.data?.detail) {
        message.error(error.response.data.detail);
      }
    }
  };

  const columns: ColumnsType<FeeAccrual> = [
    {
      title: 'Член СНТ',
      dataIndex: 'member_name',
      key: 'member_name',
      filters: members.map(m => ({ text: m.full_name, value: m.id })),
      onFilter: (value, record) => record.member_id === value,
    },
    {
      title: 'Вид взноса',
      dataIndex: 'fee_type_name',
      key: 'fee_type_name',
    },
    {
      title: 'Год',
      dataIndex: 'year',
      key: 'year',
      sorter: (a, b) => a.year - b.year,
      filters: [
        { text: '2024', value: 2024 },
        { text: '2025', value: 2025 },
        { text: '2026', value: 2026 },
        { text: '2027', value: 2027 },
      ],
      onFilter: (value, record) => record.year === value,
    },
    {
      title: 'Сумма',
      dataIndex: 'amount',
      key: 'amount',
      render: (value: number) => value.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' }),
      sorter: (a, b) => a.amount - b.amount,
    },
    {
      title: 'Оплачено',
      dataIndex: 'paid_amount',
      key: 'paid_amount',
      render: (value: number, record) => (
        <span style={{ color: '#52c41a' }}>
          {value.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' })}
        </span>
      ),
    },
    {
      title: 'Остаток',
      dataIndex: 'remaining_amount',
      key: 'remaining_amount',
      render: (value: number, record) => (
        <span style={{ color: value > 0 ? '#ff4d4f' : '#52c41a', fontWeight: 'bold' }}>
          {value > 0 ? value.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' }) : '—'}
        </span>
      ),
      sorter: (a, b) => a.remaining_amount - b.remaining_amount,
    },
    {
      title: 'Статус',
      key: 'status',
      render: (_, record) => (
        <Tag color={record.is_paid ? 'green' : 'orange'}>
          {record.is_paid ? 'Оплачено' : 'Не оплачено'}
        </Tag>
      ),
    },
    {
      title: 'Срок оплаты',
      dataIndex: 'due_date',
      key: 'due_date',
      render: (date: string | null) => date ? new Date(date).toLocaleDateString('ru-RU') : '—',
    },
  ];

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <Title level={2} style={{ margin: 0 }}>Начисления взносов</Title>
        <Space>
          <Select
            value={yearFilter}
            onChange={setYearFilter}
            style={{ width: 100 }}
            options={[
              { value: 2024, label: '2024' },
              { value: 2025, label: '2025' },
              { value: 2026, label: '2026' },
              { value: 2027, label: '2027' },
            ]}
          />
          <Button icon={<ThunderboltOutlined />} onClick={handleBulkCreate}>
            Массовое начисление
          </Button>
          <Button type="primary" icon={<PlusOutlined />} onClick={handleCreate}>
            Добавить
          </Button>
        </Space>
      </div>

      <Card style={{ marginBottom: 16 }}>
        <Row gutter={16}>
          <Col span={6}>
            <Statistic
              title="Всего начислений"
              value={accruals.length}
            />
          </Col>
          <Col span={6}>
            <Statistic
              title="Общая сумма"
              value={accruals.reduce((sum, a) => sum + a.amount, 0)}
              precision={2}
              prefix="₽"
            />
          </Col>
          <Col span={6}>
            <Statistic
              title="Оплачено"
              value={accruals.reduce((sum, a) => sum + a.paid_amount, 0)}
              precision={2}
              prefix="₽"
              valueStyle={{ color: '#52c41a' }}
            />
          </Col>
          <Col span={6}>
            <Statistic
              title="Не оплачено"
              value={accruals.reduce((sum, a) => sum + a.remaining_amount, 0)}
              precision={2}
              prefix="₽"
              valueStyle={{ color: '#ff4d4f' }}
            />
          </Col>
        </Row>
      </Card>

      <Table
        columns={columns}
        dataSource={accruals}
        rowKey="id"
        loading={loading}
        scroll={{ x: 1000 }}
      />

      {/* Create Modal */}
      <Modal
        title="Добавить начисление"
        open={modalOpen}
        onOk={handleSave}
        onCancel={() => setModalOpen(false)}
        width={500}
      >
        <Form form={form} layout="vertical">
          <Form.Item name="member_id" label="Член СНТ" rules={[{ required: true }]}>
            <Select
              showSearch
              optionFilterProp="children"
              filterOption={(input, option) =>
                (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
              }
              options={members.map(m => ({ value: m.id, label: m.full_name }))}
            />
          </Form.Item>
          <Form.Item name="fee_type_id" label="Вид взноса" rules={[{ required: true }]}>
            <Select options={feeTypes.map(ft => ({ value: ft.id, label: ft.name }))} />
          </Form.Item>
          <Form.Item name="year" label="Год" rules={[{ required: true }]} initialValue={yearFilter}>
            <InputNumber style={{ width: '100%' }} min={2020} max={2100} />
          </Form.Item>
          <Form.Item name="amount" label="Сумма (₽)" rules={[{ required: true }]}>
            <InputNumber style={{ width: '100%' }} min={0} step={0.01} />
          </Form.Item>
          <Form.Item name="due_date" label="Срок оплаты">
            <DatePicker style={{ width: '100%' }} format="DD.MM.YYYY" />
          </Form.Item>
        </Form>
      </Modal>

      {/* Bulk Create Modal */}
      <Modal
        title="Массовое начисление взносов"
        open={bulkModalOpen}
        onOk={handleBulkSave}
        onCancel={() => setBulkModalOpen(false)}
        width={500}
      >
        <Form form={bulkForm} layout="vertical">
          <Form.Item name="fee_type_id" label="Вид взноса" rules={[{ required: true }]}>
            <Select options={feeTypes.map(ft => ({ value: ft.id, label: ft.name }))} />
          </Form.Item>
          <Form.Item name="year" label="Год" rules={[{ required: true }]}>
            <InputNumber style={{ width: '100%' }} min={2020} max={2100} />
          </Form.Item>
          <Form.Item name="rate_per_sotka" label="Ставка (₽/сотка)" rules={[{ required: true }]}>
            <InputNumber style={{ width: '100%' }} min={0} step={0.01} />
          </Form.Item>
          <Form.Item name="due_date" label="Срок оплаты" rules={[{ required: true }]}>
            <DatePicker style={{ width: '100%' }} format="DD.MM.YYYY" />
          </Form.Item>
        </Form>
        <p style={{ color: '#666', fontSize: 12 }}>
          Начисления будут созданы для всех активных членов СНТ на основе площади их участков.
        </p>
      </Modal>
    </div>
  );
};

export default Accruals;
