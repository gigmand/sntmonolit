import React, { useEffect, useState } from 'react';
import { Card, Select, Table, Tag, Typography, Row, Col, Statistic, Spin } from 'antd';
import { dashboardApi } from '@/services/api';
import type { MemberListItem } from '@/types/api';
import { DollarOutlined, CheckCircleOutlined, ExclamationCircleOutlined } from '@ant-design/icons';

const { Title } = Typography;

const Reports: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [year, setYear] = useState(new Date().getFullYear());
  const [feesReport, setFeesReport] = useState<any>(null);
  const [debtorsReport, setDebtorsReport] = useState<MemberListItem[]>([]);

  useEffect(() => {
    loadReports();
  }, [year]);

  const loadReports = async () => {
    try {
      setLoading(true);
      const [feesData, debtorsData] = await Promise.all([
        dashboardApi.getFeesReport(year),
        dashboardApi.getDebtorsReport(),
      ]);
      setFeesReport(feesData);
      setDebtorsReport(debtorsData);
    } catch (error) {
      console.error('Failed to load reports:', error);
    } finally {
      setLoading(false);
    }
  };

  const debtorsColumns = [
    {
      title: 'ФИО',
      dataIndex: 'full_name',
      key: 'full_name',
    },
    {
      title: 'Телефон',
      dataIndex: 'phone',
      key: 'phone',
    },
    {
      title: 'Участков',
      dataIndex: 'plot_count',
      key: 'plot_count',
      align: 'center',
    },
    {
      title: 'Долг',
      dataIndex: 'total_debt',
      key: 'total_debt',
      render: (value: number) => (
        <span style={{ color: '#ff4d4f', fontWeight: 'bold' }}>
          {value.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' })}
        </span>
      ),
      sorter: (a, b) => a.total_debt - b.total_debt,
    },
    {
      title: 'Категория',
      dataIndex: 'debt_category',
      key: 'debt_category',
      render: (category: string) => {
        const colorMap: Record<string, string> = {
          small: 'orange',
          medium: 'volcano',
          large: 'red',
        };
        const labelMap: Record<string, string> = {
          small: 'Мелкий (<1000 ₽)',
          medium: 'Средний (1000-5000 ₽)',
          large: 'Крупный (>5000 ₽)',
        };
        return <Tag color={colorMap[category]}>{labelMap[category] || category}</Tag>;
      },
    },
  ];

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: 64 }}>
        <Spin size="large" />
      </div>
    );
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <Title level={2} style={{ margin: 0 }}>Отчеты</Title>
        <Select
          value={year}
          onChange={setYear}
          style={{ width: 120 }}
          options={[
            { value: 2024, label: '2024' },
            { value: 2025, label: '2025' },
            { value: 2026, label: '2026' },
            { value: 2027, label: '2027' },
          ]}
        />
      </div>

      {/* Fees Report */}
      <Card title={`Отчет по взносам за ${year}`} style={{ marginBottom: 24 }}>
        {feesReport && (
          <>
            <Row gutter={16} style={{ marginBottom: 24 }}>
              <Col span={8}>
                <Statistic
                  title="Начислено"
                  value={feesReport.total_accruals}
                  precision={2}
                  prefix={<DollarOutlined />}
                  valueStyle={{ color: '#1890ff' }}
                />
              </Col>
              <Col span={8}>
                <Statistic
                  title="Оплачено"
                  value={feesReport.total_paid}
                  precision={2}
                  prefix={<CheckCircleOutlined />}
                  valueStyle={{ color: '#52c41a' }}
                />
              </Col>
              <Col span={8}>
                <Statistic
                  title="Остаток долга"
                  value={feesReport.total_remaining}
                  precision={2}
                  prefix={<ExclamationCircleOutlined />}
                  valueStyle={{ color: '#faad14' }}
                />
              </Col>
            </Row>

            <Table
              columns={[
                {
                  title: 'Вид взноса',
                  dataIndex: 'type',
                  key: 'type',
                  render: (_, record) => record.key,
                },
                {
                  title: 'Начислено',
                  dataIndex: 'accruals',
                  key: 'accruals',
                  render: (value: number) => value.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' }),
                },
                {
                  title: 'Оплачено',
                  dataIndex: 'paid',
                  key: 'paid',
                  render: (value: number) => value.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' }),
                },
                {
                  title: 'Остаток',
                  dataIndex: 'remaining',
                  key: 'remaining',
                  render: (value: number) => (
                    <span style={{ color: value > 0 ? '#ff4d4f' : '#52c41a' }}>
                      {value.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' })}
                    </span>
                  ),
                },
                {
                  title: '% оплаты',
                  key: 'percent',
                  render: (_, record) => {
                    const percent = record.accruals > 0 
                      ? ((record.paid / record.accruals) * 100).toFixed(1)
                      : 0;
                    return `${percent}%`;
                  },
                },
              ]}
              dataSource={Object.entries(feesReport.by_type).map(([key, value]: [string, any]) => ({
                key,
                ...value,
              }))}
              rowKey="key"
              pagination={false}
              summary={(pageData) => {
                let totalAccruals = 0;
                let totalPaid = 0;
                let totalRemaining = 0;

                pageData.forEach(({ accruals, paid, remaining }) => {
                  totalAccruals += accruals;
                  totalPaid += paid;
                  totalRemaining += remaining;
                });

                return (
                  <Table.Summary fixed>
                    <Table.Summary.Row>
                      <Table.Summary.Cell index={0}><strong>Итого</strong></Table.Summary.Cell>
                      <Table.Summary.Cell index={1}>
                        <strong>{totalAccruals.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' })}</strong>
                      </Table.Summary.Cell>
                      <Table.Summary.Cell index={2}>
                        <strong>{totalPaid.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' })}</strong>
                      </Table.Summary.Cell>
                      <Table.Summary.Cell index={3}>
                        <strong>{totalRemaining.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' })}</strong>
                      </Table.Summary.Cell>
                      <Table.Summary.Cell index={4} />
                    </Table.Summary.Row>
                  </Table.Summary>
                );
              }}
            />
          </>
        )}
      </Card>

      {/* Debtors Report */}
      <Card title="Отчет по должникам">
        <Row gutter={16} style={{ marginBottom: 16 }}>
          <Col span={8}>
            <Statistic
              title="Всего должников"
              value={debtorsReport.length}
              valueStyle={{ color: '#faad14' }}
            />
          </Col>
          <Col span={8}>
            <Statistic
              title="Общая сумма долга"
              value={debtorsReport.reduce((sum, d) => sum + d.total_debt, 0)}
              precision={2}
              prefix="₽"
              valueStyle={{ color: '#ff4d4f' }}
            />
          </Col>
          <Col span={8}>
            <Statistic
              title="Крупные должники"
              value={debtorsReport.filter(d => d.debt_category === 'large').length}
              valueStyle={{ color: '#ff4d4f' }}
            />
          </Col>
        </Row>

        <Table
          columns={debtorsColumns}
          dataSource={debtorsReport}
          rowKey="id"
          scroll={{ x: 800 }}
        />
      </Card>
    </div>
  );
};

export default Reports;
