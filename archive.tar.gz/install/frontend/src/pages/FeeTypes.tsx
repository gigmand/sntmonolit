import React, { useEffect, useState } from 'react';
import {
  Table, Button, Space, Modal, Form, Input, Switch,
  message, Tag, Typography,
} from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { PlusOutlined, EditOutlined } from '@ant-design/icons';
import { feesApi } from '@/services/api';
import type { FeeType } from '@/types/api';

const { Title } = Typography;

const FeeTypes: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [feeTypes, setFeeTypes] = useState<FeeType[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingType, setEditingType] = useState<FeeType | null>(null);
  const [form] = Form.useForm();

  useEffect(() => {
    loadFeeTypes();
  }, []);

  const loadFeeTypes = async () => {
    try {
      setLoading(true);
      const data = await feesApi.getFeeTypes(false);
      setFeeTypes(data);
    } catch (error) {
      message.error('Ошибка загрузки видов взносов');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (feeType: FeeType) => {
    setEditingType(feeType);
    form.setFieldsValue({
      name: feeType.name,
      description: feeType.description,
      is_active: feeType.is_active,
    });
    setModalOpen(true);
  };

  const handleSave = async () => {
    try {
      const values = await form.validateFields();
      if (editingType) {
        await feesApi.updateFeeType(editingType.id, values);
        message.success('Вид взноса обновлен');
      }
      setModalOpen(false);
      loadFeeTypes();
    } catch (error: any) {
      if (error?.response?.data?.detail) {
        message.error(error.response.data.detail);
      }
    }
  };

  const columns: ColumnsType<FeeType> = [
    {
      title: 'Наименование',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: 'Код',
      dataIndex: 'code',
      key: 'code',
      render: (code: string) => <Tag>{code}</Tag>,
    },
    {
      title: 'Описание',
      dataIndex: 'description',
      key: 'description',
    },
    {
      title: 'Статус',
      key: 'is_active',
      render: (isActive: boolean) => (
        <Tag color={isActive ? 'green' : 'default'}>
          {isActive ? 'Активный' : 'Неактивный'}
        </Tag>
      ),
    },
    {
      title: 'Действия',
      key: 'actions',
      render: (_, record) => (
        <Button
          type="link"
          icon={<EditOutlined />}
          onClick={() => handleEdit(record)}
        />
      ),
    },
  ];

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
        <Title level={2} style={{ margin: 0 }}>Виды взносов</Title>
      </div>

      <Table
        columns={columns}
        dataSource={feeTypes}
        rowKey="id"
        loading={loading}
      />

      {/* Edit Modal */}
      <Modal
        title="Редактировать вид взноса"
        open={modalOpen}
        onOk={handleSave}
        onCancel={() => setModalOpen(false)}
        width={500}
      >
        <Form form={form} layout="vertical">
          <Form.Item name="name" label="Наименование" rules={[{ required: true }]}>
            <Input />
          </Form.Item>
          <Form.Item name="description" label="Описание">
            <Input.TextArea rows={3} />
          </Form.Item>
          <Form.Item name="is_active" label="Активный" valuePropName="checked">
            <Switch />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default FeeTypes;
