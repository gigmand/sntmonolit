import React, { useEffect, useState } from 'react';
import {
  Table, Button, Space, Input, Select, Tag, Modal, Form,
  DatePicker, message, Popconfirm, Drawer, Descriptions, Switch,
} from 'antd';
import type { ColumnsType } from 'antd/es/table';
import {
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  EyeOutlined,
  SearchOutlined,
} from '@ant-design/icons';
import { membersApi } from '@/services/api';
import type { Member, MemberListItem, MemberStatus } from '@/types/api';
import dayjs from 'dayjs';

const { Search } = Input;

const Members: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [members, setMembers] = useState<MemberListItem[]>([]);
  const [selectedMember, setSelectedMember] = useState<MemberDetail | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<Member | null>(null);
  const [form] = Form.useForm();
  const [searchText, setSearchText] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('');

  useEffect(() => {
    loadMembers();
  }, [statusFilter]);

  const loadMembers = async () => {
    try {
      setLoading(true);
      const params: Record<string, any> = { limit: 100 };
      if (searchText) params.search = searchText;
      if (statusFilter) params.status = statusFilter;
      
      const data = await membersApi.getAll(params);
      setMembers(data);
    } catch (error) {
      message.error('Ошибка загрузки членов СНТ');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (value: string) => {
    setSearchText(value);
    setTimeout(loadMembers, 500);
  };

  const handleView = async (id: number) => {
    try {
      const member = await membersApi.getById(id);
      setSelectedMember(member);
      setDrawerOpen(true);
    } catch (error) {
      message.error('Ошибка загрузки данных');
    }
  };

  const handleEdit = (member: MemberListItem) => {
    setEditingMember(member);
    form.setFieldsValue({
      ...member,
      birth_date: member.birth_date ? dayjs(member.birth_date) : null,
      membership_start_date: member.membership_start_date ? dayjs(member.membership_start_date) : null,
      membership_end_date: member.membership_end_date ? dayjs(member.membership_end_date) : null,
    });
    setModalOpen(true);
  };

  const handleCreate = () => {
    setEditingMember(null);
    form.resetFields();
    setModalOpen(true);
  };

  const handleSave = async () => {
    try {
      const values = await form.validateFields();
      const memberData = {
        ...values,
        birth_date: values.birth_date ? values.birth_date.format('YYYY-MM-DD') : null,
        membership_start_date: values.membership_start_date ? values.membership_start_date.format('YYYY-MM-DD') : null,
        membership_end_date: values.membership_end_date ? values.membership_end_date.format('YYYY-MM-DD') : null,
      };

      if (editingMember) {
        await membersApi.update(editingMember.id, memberData);
        message.success('Член СНТ обновлен');
      } else {
        await membersApi.create(memberData);
        message.success('Член СНТ создан');
      }
      
      setModalOpen(false);
      loadMembers();
    } catch (error: any) {
      if (error?.response?.data?.detail) {
        message.error(error.response.data.detail);
      }
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await membersApi.delete(id);
      message.success('Член СНТ удален');
      loadMembers();
    } catch (error) {
      message.error('Ошибка удаления');
    }
  };

  const getStatusColor = (status: MemberStatus) => {
    const colorMap: Record<MemberStatus, string> = {
      active: 'green',
      debtor: 'orange',
      former: 'gray',
      deceased: 'red',
    };
    return colorMap[status];
  };

  const getStatusLabel = (status: MemberStatus) => {
    const labelMap: Record<MemberStatus, string> = {
      active: 'Действительный',
      debtor: 'Должник',
      former: 'Бывший',
      deceased: 'Умерший',
    };
    return labelMap[status];
  };

  const columns: ColumnsType<MemberListItem> = [
    {
      title: 'ФИО',
      dataIndex: 'full_name',
      key: 'full_name',
      sorter: (a, b) => a.full_name.localeCompare(b.full_name),
    },
    {
      title: 'Телефон',
      dataIndex: 'phone',
      key: 'phone',
    },
    {
      title: 'Email',
      dataIndex: 'email',
      key: 'email',
    },
    {
      title: 'Участков',
      dataIndex: 'plot_count',
      key: 'plot_count',
      align: 'center',
    },
    {
      title: 'Долг',
      dataIndex: 'total_debt',
      key: 'total_debt',
      render: (value: number) => (
        <span style={{ color: value > 0 ? '#ff4d4f' : '#52c41a', fontWeight: 'bold' }}>
          {value > 0 ? `-${value.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' })}` : '—'}
        </span>
      ),
      sorter: (a, b) => a.total_debt - b.total_debt,
    },
    {
      title: 'Статус',
      dataIndex: 'status',
      key: 'status',
      render: (status: MemberStatus) => (
        <Tag color={getStatusColor(status)}>{getStatusLabel(status)}</Tag>
      ),
      filters: [
        { text: 'Действительный', value: 'active' },
        { text: 'Должник', value: 'debtor' },
        { text: 'Бывший', value: 'former' },
        { text: 'Умерший', value: 'deceased' },
      ],
      onFilter: (value, record) => record.status === value,
    },
    {
      title: 'Действия',
      key: 'actions',
      render: (_, record) => (
        <Space>
          <Button
            type="link"
            icon={<EyeOutlined />}
            onClick={() => handleView(record.id)}
          />
          <Button
            type="link"
            icon={<EditOutlined />}
            onClick={() => handleEdit(record)}
          />
          <Popconfirm
            title="Удалить члена СНТ?"
            onConfirm={() => handleDelete(record.id)}
            okText="Да"
            cancelText="Отмена"
          >
            <Button type="link" danger icon={<DeleteOutlined />} />
          </Popconfirm>
        </Space>
      ),
    },
  ];

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
        <Space>
          <Search
            placeholder="Поиск по ФИО, телефону"
            allowClear
            onSearch={handleSearch}
            style={{ width: 300 }}
          />
          <Select
            placeholder="Статус"
            allowClear
            style={{ width: 150 }}
            onChange={setStatusFilter}
            options={[
              { value: 'active', label: 'Действительный' },
              { value: 'debtor', label: 'Должник' },
              { value: 'former', label: 'Бывший' },
              { value: 'deceased', label: 'Умерший' },
            ]}
          />
        </Space>
        <Button type="primary" icon={<PlusOutlined />} onClick={handleCreate}>
          Добавить
        </Button>
      </div>

      <Table
        columns={columns}
        dataSource={members}
        rowKey="id"
        loading={loading}
        scroll={{ x: 1000 }}
      />

      {/* View Drawer */}
      <Drawer
        title="Карточка члена СНТ"
        placement="right"
        width={600}
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
      >
        {selectedMember && (
          <Descriptions column={1} bordered>
            <Descriptions.Item label="ФИО">{selectedMember.full_name}</Descriptions.Item>
            <Descriptions.Item label="Дата рождения">
              {selectedMember.birth_date ? new Date(selectedMember.birth_date).toLocaleDateString('ru-RU') : '—'}
            </Descriptions.Item>
            <Descriptions.Item label="Телефон">{selectedMember.phone || '—'}</Descriptions.Item>
            <Descriptions.Item label="Email">{selectedMember.email || '—'}</Descriptions.Item>
            <Descriptions.Item label="Адрес">{selectedMember.address || '—'}</Descriptions.Item>
            <Descriptions.Item label="Статус">
              <Tag color={getStatusColor(selectedMember.status)}>
                {getStatusLabel(selectedMember.status)}
              </Tag>
            </Descriptions.Item>
            <Descriptions.Item label="Дата вступления">
              {selectedMember.membership_start_date 
                ? new Date(selectedMember.membership_start_date).toLocaleDateString('ru-RU') 
                : '—'}
            </Descriptions.Item>
            <Descriptions.Item label="Долг">
              <span style={{ color: selectedMember.total_debt > 0 ? '#ff4d4f' : '#52c41a' }}>
                {selectedMember.total_debt > 0 
                  ? selectedMember.total_debt.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' })
                  : 'Нет'}
              </span>
            </Descriptions.Item>
            <Descriptions.Item label="Участки">
              {selectedMember.plots.length > 0 ? (
                <ul>
                  {selectedMember.plots.map((plot) => (
                    <li key={plot.id}>
                      №{plot.plot_number} ({plot.area} сот.)
                    </li>
                  ))}
                </ul>
              ) : '—'}
            </Descriptions.Item>
          </Descriptions>
        )}
      </Drawer>

      {/* Edit/Create Modal */}
      <Modal
        title={editingMember ? 'Редактировать' : 'Новый член СНТ'}
        open={modalOpen}
        onOk={handleSave}
        onCancel={() => setModalOpen(false)}
        width={600}
      >
        <Form form={form} layout="vertical">
          <Form.Item name="last_name" label="Фамилия" rules={[{ required: true }]}>
            <Input />
          </Form.Item>
          <Form.Item name="first_name" label="Имя" rules={[{ required: true }]}>
            <Input />
          </Form.Item>
          <Form.Item name="middle_name" label="Отчество">
            <Input />
          </Form.Item>
          <Form.Item name="birth_date" label="Дата рождения">
            <DatePicker style={{ width: '100%' }} format="DD.MM.YYYY" />
          </Form.Item>
          <Form.Item name="phone" label="Телефон">
            <Input />
          </Form.Item>
          <Form.Item name="email" label="Email">
            <Input type="email" />
          </Form.Item>
          <Form.Item name="address" label="Адрес">
            <Input.TextArea rows={2} />
          </Form.Item>
          <Form.Item name="membership_start_date" label="Дата вступления">
            <DatePicker style={{ width: '100%' }} format="DD.MM.YYYY" />
          </Form.Item>
          <Form.Item name="status" label="Статус">
            <Select>
              <Select.Option value="active">Действительный</Select.Option>
              <Select.Option value="debtor">Должник</Select.Option>
              <Select.Option value="former">Бывший</Select.Option>
              <Select.Option value="deceased">Умерший</Select.Option>
            </Select>
          </Form.Item>
          <Form.Item name="has_irrigation" label="Полив на участке" valuePropName="checked">
            <Switch checkedChildren="Есть" unCheckedChildren="Нет" />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default Members;
