import axios from 'axios';
import type {
  User,
  Member,
  MemberListItem,
  MemberDetail,
  Plot,
  PlotListItem,
  PlotDetail,
  OwnershipHistoryItem,
  FeeType,
  FeeRate,
  FeeAccrual,
  FeePayment,
  FeePaymentDetail,
  DashboardData,
  TokenResponse,
  LoginRequest,
} from '@/types/api';

const API_BASE = '/api';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authApi = {
  login: async (credentials: LoginRequest): Promise<TokenResponse> => {
    const formData = new FormData();
    formData.append('username', credentials.username);
    formData.append('password', credentials.password);
    
    const response = await api.post<TokenResponse>('/auth/login', formData, {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    });
    return response.data;
  },

  register: async (userData: Partial<User> & { password: string }): Promise<User> => {
    const response = await api.post<User>('/auth/register', userData);
    return response.data;
  },

  getMe: async (): Promise<User> => {
    const response = await api.get<User>('/auth/me');
    return response.data;
  },

  logout: async (): Promise<void> => {
    await api.post('/auth/logout');
  },
};

// Members API
export const membersApi = {
  getAll: async (params?: {
    skip?: number;
    limit?: number;
    search?: string;
    status?: string;
    has_debt?: boolean;
  }): Promise<MemberListItem[]> => {
    const response = await api.get<MemberListItem[]>('/members', { params });
    return response.data;
  },

  getById: async (id: number): Promise<MemberDetail> => {
    const response = await api.get<MemberDetail>(`/members/${id}`);
    return response.data;
  },

  create: async (member: Partial<Member>): Promise<Member> => {
    const response = await api.post<Member>('/members', member);
    return response.data;
  },

  update: async (id: number, member: Partial<Member>): Promise<Member> => {
    const response = await api.put<Member>(`/members/${id}`, member);
    return response.data;
  },

  delete: async (id: number): Promise<void> => {
    await api.delete(`/members/${id}`);
  },
};

// Plots API
export const plotsApi = {
  getAll: async (params?: {
    skip?: number;
    limit?: number;
    search?: string;
    status?: string;
  }): Promise<PlotListItem[]> => {
    const response = await api.get<PlotListItem[]>('/plots', { params });
    return response.data;
  },

  getById: async (id: number): Promise<PlotDetail> => {
    const response = await api.get<PlotDetail>(`/plots/${id}`);
    return response.data;
  },

  create: async (plot: Partial<Plot>): Promise<Plot> => {
    const response = await api.post<Plot>('/plots', plot);
    return response.data;
  },

  update: async (id: number, plot: Partial<Plot>): Promise<Plot> => {
    const response = await api.put<Plot>(`/plots/${id}`, plot);
    return response.data;
  },

  delete: async (id: number): Promise<void> => {
    await api.delete(`/plots/${id}`);
  },

  getHistory: async (plotId: number): Promise<OwnershipHistoryItem[]> => {
    const response = await api.get<OwnershipHistoryItem[]>(`/plots/${plotId}/history`);
    return response.data;
  },

  addHistory: async (plotId: number, history: Partial<OwnershipHistoryItem>): Promise<OwnershipHistoryItem> => {
    const response = await api.post<OwnershipHistoryItem>(`/plots/${plotId}/history`, history);
    return response.data;
  },
};

// Fees API
export const feesApi = {
  // Fee Types
  getFeeTypes: async (activeOnly = true): Promise<FeeType[]> => {
    const response = await api.get<FeeType[]>('/fees/types', { params: { active_only: activeOnly } });
    return response.data;
  },

  createFeeType: async (feeType: Partial<FeeType>): Promise<FeeType> => {
    const response = await api.post<FeeType>('/fees/types', feeType);
    return response.data;
  },

  // Fee Rates
  getFeeRates: async (year?: number): Promise<FeeRate[]> => {
    const response = await api.get<FeeRate[]>('/fees/rates', { params: { year } });
    return response.data;
  },

  createFeeRate: async (feeRate: Partial<FeeRate>): Promise<FeeRate> => {
    const response = await api.post<FeeRate>('/fees/rates', feeRate);
    return response.data;
  },

  // Accruals
  getAccruals: async (params?: { member_id?: number; year?: number }): Promise<FeeAccrual[]> => {
    const response = await api.get<FeeAccrual[]>('/fees/accruals', { params });
    return response.data;
  },

  createAccrual: async (accrual: Partial<FeeAccrual>): Promise<FeeAccrual> => {
    const response = await api.post<FeeAccrual>('/fees/accruals', accrual);
    return response.data;
  },

  createBulkAccruals: async (params: {
    fee_type_id: number;
    year: number;
    rate_per_sotka: number;
    due_date: string;
  }): Promise<{ message: string }> => {
    const response = await api.post('/fees/accruals/bulk', null, { params });
    return response.data;
  },

  // Payments
  getPayments: async (params?: { member_id?: number; limit?: number }): Promise<FeePayment[]> => {
    const response = await api.get<FeePayment[]>('/fees/payments', { params });
    return response.data;
  },

  getPaymentById: async (id: number): Promise<FeePaymentDetail> => {
    const response = await api.get<FeePaymentDetail>(`/fees/payments/${id}`);
    return response.data;
  },

  createPayment: async (payment: {
    member_id: number;
    amount: number;
    payment_date: string;
    payment_method: string;
    comment?: string;
    splits: { accrual_id: number; amount: number }[];
  }): Promise<FeePayment> => {
    const response = await api.post<FeePayment>('/fees/payments', payment);
    return response.data;
  },
};

// Dashboard API
export const dashboardApi = {
  getDashboard: async (year?: number): Promise<DashboardData> => {
    const response = await api.get<DashboardData>('/dashboard', { params: { year } });
    return response.data;
  },

  getStats: async (): Promise<DashboardData['stats']> => {
    const response = await api.get<DashboardData['stats']>('/dashboard/stats');
    return response.data;
  },

  getDebtorsReport: async (category?: string): Promise<MemberListItem[]> => {
    const response = await api.get<MemberListItem[]>('/dashboard/reports/debtors', { params: { category } });
    return response.data;
  },

  getFeesReport: async (year?: number): Promise<{
    year: number;
    total_accruals: number;
    total_paid: number;
    total_remaining: number;
    by_type: Record<string, { accruals: number; paid: number; remaining: number }>;
  }> => {
    const response = await api.get('/dashboard/reports/fees', { params: { year } });
    return response.data;
  },
};

export default api;
