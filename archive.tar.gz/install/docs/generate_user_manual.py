#!/usr/bin/env python3
"""
Генератор руководства пользователя АИС "СНТ-Управление"
Создает PDF-документацию с описанием возможностей и инструкциями
"""

import os
from datetime import datetime
from weasyprint import HTML, CSS
from weasyprint.text.fonts import FontConfiguration

# Директория для выходных файлов
OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOADS_DIR = os.path.join(os.path.dirname(OUTPUT_DIR), 'uploads')

# HTML-шаблон руководства
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Руководство пользователя АИС "СНТ-Управление"</title>
    <style>
        @page {{
            size: A4;
            margin: 2cm;
            @bottom-right {{
                content: "Страница " counter(page) " из " counter(pages);
                font-size: 10pt;
                color: #666;
            }}
            @bottom-left {{
                content: "АИС СНТ-Управление";
                font-size: 10pt;
                color: #666;
            }}
        }}
        
        @page :first {{
            @bottom-right {{ content: ""; }}
            @bottom-left {{ content: ""; }}
        }}
        
        body {{
            font-family: "Segoe UI", "DejaVu Sans", Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            font-size: 11pt;
        }}
        
        h1 {{
            color: #1890ff;
            font-size: 24pt;
            border-bottom: 3px solid #1890ff;
            padding-bottom: 10px;
            margin-top: 0;
        }}
        
        h2 {{
            color: #096dd9;
            font-size: 18pt;
            border-bottom: 1px solid #d9d9d9;
            padding-bottom: 8px;
            margin-top: 30px;
        }}
        
        h3 {{
            color: #0050b3;
            font-size: 14pt;
            margin-top: 20px;
        }}
        
        .cover {{
            text-align: center;
            padding: 100px 0;
            page-break-after: always;
        }}
        
        .cover h1 {{
            font-size: 32pt;
            border: none;
            color: #1890ff;
        }}
        
        .cover .subtitle {{
            font-size: 16pt;
            color: #666;
            margin-top: 20px;
        }}
        
        .cover .version {{
            margin-top: 80px;
            font-size: 12pt;
            color: #999;
        }}
        
        .cover .logo {{
            font-size: 80pt;
            color: #1890ff;
            margin-bottom: 40px;
        }}
        
        .toc {{
            page-break-after: always;
        }}
        
        .toc h2 {{
            border: none;
        }}
        
        .toc ul {{
            list-style: none;
            padding-left: 0;
        }}
        
        .toc li {{
            margin: 10px 0;
            padding: 5px 0;
            border-bottom: 1px dotted #ccc;
        }}
        
        .toc a {{
            color: #1890ff;
            text-decoration: none;
        }}
        
        .info-box {{
            background: #e6f7ff;
            border-left: 4px solid #1890ff;
            padding: 15px;
            margin: 20px 0;
            border-radius: 0 4px 4px 0;
        }}
        
        .warning-box {{
            background: #fff7e6;
            border-left: 4px solid #fa8c16;
            padding: 15px;
            margin: 20px 0;
            border-radius: 0 4px 4px 0;
        }}
        
        .success-box {{
            background: #f6ffed;
            border-left: 4px solid #52c41a;
            padding: 15px;
            margin: 20px 0;
            border-radius: 0 4px 4px 0;
        }}
        
        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 10pt;
        }}
        
        th, td {{
            border: 1px solid #d9d9d9;
            padding: 10px;
            text-align: left;
        }}
        
        th {{
            background: #fafafa;
            font-weight: 600;
            color: #000;
        }}
        
        tr:nth-child(even) {{
            background: #fafafa;
        }}
        
        .step {{
            margin: 15px 0;
            padding: 15px;
            background: #fff;
            border: 1px solid #d9d9d9;
            border-radius: 4px;
        }}
        
        .step-number {{
            display: inline-block;
            width: 28px;
            height: 28px;
            background: #1890ff;
            color: white;
            text-align: center;
            line-height: 28px;
            border-radius: 50%;
            margin-right: 10px;
            font-weight: bold;
        }}
        
        .feature-grid {{
            display: table;
            width: 100%;
        }}
        
        .feature-item {{
            display: table-cell;
            width: 50%;
            padding: 15px;
            vertical-align: top;
        }}
        
        .feature-icon {{
            font-size: 24pt;
            color: #1890ff;
            margin-bottom: 10px;
        }}
        
        code {{
            background: #f5f5f5;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: "Consolas", "Courier New", monospace;
            font-size: 10pt;
            color: #c41d7f;
        }}
        
        .keyboard {{
            background: #fafafa;
            border: 1px solid #d9d9d9;
            border-radius: 3px;
            padding: 2px 8px;
            font-family: "Consolas", monospace;
            font-size: 10pt;
            box-shadow: 0 1px 0 #d9d9d9;
        }}
        
        ul {{
            padding-left: 25px;
        }}
        
        li {{
            margin: 8px 0;
        }}
        
        .screenshot-placeholder {{
            background: #f5f5f5;
            border: 2px dashed #d9d9d9;
            border-radius: 8px;
            padding: 40px 20px;
            text-align: center;
            margin: 20px 0;
            color: #999;
            font-size: 10pt;
        }}
        
        .screenshot-caption {{
            text-align: center;
            font-size: 9pt;
            color: #666;
            font-style: italic;
            margin-top: -15px;
            margin-bottom: 20px;
        }}
        
        .contact-info {{
            background: #fafafa;
            padding: 20px;
            border-radius: 8px;
            margin-top: 30px;
        }}
        
        .contact-info p {{
            margin: 5px 0;
        }}
        
        .role-badge {{
            display: inline-block;
            padding: 3px 10px;
            background: #1890ff;
            color: white;
            border-radius: 12px;
            font-size: 9pt;
            margin: 2px;
        }}
        
        .page-break {{
            page-break-after: always;
        }}
    </style>
</head>
<body>
    {content}
</body>
</html>
"""

# Содержание документа
CONTENT = """
<!-- Обложка -->
<div class="cover">
    <div class="logo">🏡</div>
    <h1>АИС "СНТ-Управление"</h1>
    <div class="subtitle">Руководство пользователя</div>
    <div class="version">
        Версия 1.0<br>
        {date}
    </div>
</div>

<!-- Оглавление -->
<div class="toc">
    <h2>📑 Оглавление</h2>
    <ul>
        <li><a href="#about">1. О системе</a></li>
        <li><a href="#features">2. Основные возможности</a></li>
        <li><a href="#roles">3. Роли и права доступа</a></li>
        <li><a href="#login">4. Вход в систему</a></li>
        <li><a href="#dashboard">5. Дашборд</a></li>
        <li><a href="#members">6. Управление членами СНТ</a></li>
        <li><a href="#plots">7. Управление участками</a></li>
        <li><a href="#accruals">8. Начисление взносов</a></li>
        <li><a href="#payments">9. Регистрация платежей</a></li>
        <li><a href="#reports">10. Отчёты</a></li>
        <li><a href="#faq">11. Часто задаваемые вопросы</a></li>
        <li><a href="#contacts">12. Контакты</a></li>
    </ul>
</div>

<!-- Раздел 1: О системе -->
<h2 id="about">1. О системе</h2>

<p><strong>АИС "СНТ-Управление"</strong> — автоматизированная информационная система для управления садоводческим некоммерческим товариществом.</p>

<div class="info-box">
    <strong>Назначение системы:</strong> Автоматизация учёта членов СНТ, управления земельными участками, контроля взносов и платежей, формирования отчётности.
</div>

<h3>Технологический стек</h3>

<table>
    <tr>
        <th>Компонент</th>
        <th>Технология</th>
    </tr>
    <tr>
        <td>Frontend (интерфейс)</td>
        <td>React 18 + TypeScript + Ant Design</td>
    </tr>
    <tr>
        <td>Backend (сервер)</td>
        <td>Python 3.11 + FastAPI</td>
    </tr>
    <tr>
        <td>База данных</td>
        <td>MariaDB 10.11+</td>
    </tr>
    <tr>
        <td>Генерация PDF</td>
        <td>WeasyPrint</td>
    </tr>
</table>

<!-- Раздел 2: Основные возможности -->
<h2 id="features">2. Основные возможности</h2>

<div class="feature-grid">
    <div class="feature-item">
        <div class="feature-icon">👥</div>
        <strong>Управление членской базой</strong>
        <p>Учёт членов СНТ, статусов, контактных данных, истории членства.</p>
    </div>
    <div class="feature-item">
        <div class="feature-icon">🏘️</div>
        <strong>Управление участками</strong>
        <p>Реестр земельных участков, привязка к владельцам, кадастровый учёт.</p>
    </div>
    <div class="feature-item">
        <div class="feature-icon">📜</div>
        <strong>История владения</strong>
        <p>Фиксация смены владельцев: продажа, наследование, дарение.</p>
    </div>
    <div class="feature-item">
        <div class="feature-icon">💰</div>
        <strong>Учёт взносов</strong>
        <p>Членские, целевые взносы, электроэнергия. Ставки по годам.</p>
    </div>
    <div class="feature-item">
        <div class="feature-icon">💳</div>
        <strong>Платежи</strong>
        <p>Регистрация платежей, распределение по начислениям, квитанции.</p>
    </div>
    <div class="feature-item">
        <div class="feature-icon">📊</div>
        <strong>Отчётность</strong>
        <p>Дашборд, отчёты по должникам, аналитика поступлений.</p>
    </div>
    <div class="feature-item">
        <div class="feature-icon">🖨️</div>
        <strong>Квитанции</strong>
        <p>Генерация PDF-квитанций об оплате для членов СНТ.</p>
    </div>
    <div class="feature-item">
        <div class="feature-icon">🔒</div>
        <strong>Разграничение прав</strong>
        <p>5 ролей пользователей с разными правами доступа.</p>
    </div>
</div>

<!-- Раздел 3: Роли -->
<h2 id="roles">3. Роли и права доступа</h2>

<table>
    <tr>
        <th>Роль</th>
        <th>Описание</th>
        <th>Права</th>
    </tr>
    <tr>
        <td><span class="role-badge">admin</span></td>
        <td>Администратор</td>
        <td>Полный доступ ко всем функциям системы</td>
    </tr>
    <tr>
        <td><span class="role-badge">chairman</span></td>
        <td>Председатель</td>
        <td>Просмотр всех данных, создание отчётов</td>
    </tr>
    <tr>
        <td><span class="role-badge">treasurer</span></td>
        <td>Казначей</td>
        <td>Работа с платежами и начислениями</td>
    </tr>
    <tr>
        <td><span class="role-badge">secretary</span></td>
        <td>Секретарь</td>
        <td>Работа с членской базой</td>
    </tr>
    <tr>
        <td><span class="role-badge">observer</span></td>
        <td>Наблюдатель</td>
        <td>Только просмотр данных</td>
    </tr>
</table>

<div class="warning-box">
    <strong>Важно!</strong> Учётные данные по умолчанию:<br>
    <code>Логин: admin</code> | <code>Пароль: admin123</code><br><br>
    Рекомендуется сменить пароль после первого входа!
</div>

<!-- Раздел 4: Вход в систему -->
<h2 id="login">4. Вход в систему</h2>

<h3>Как войти в систему:</h3>

<div class="step">
    <span class="step-number">1</span>
    <strong>Откройте браузер</strong> и перейдите по адресу:
    <br><code>http://ваш-сервер</code> или <code>http://localhost</code>
</div>

<div class="step">
    <span class="step-number">2</span>
    <strong>Введите учётные данные</strong> в форму входа:
    <ul>
        <li><strong>Логин:</strong> ваше имя пользователя</li>
        <li><strong>Пароль:</strong> ваш пароль</li>
    </ul>
</div>

<div class="step">
    <span class="step-number">3</span>
    <strong>Нажмите кнопку «Войти»</strong>
</div>

<div class="success-box">
    <strong>Успешный вход!</strong> После авторизации вы попадёте на главную страницу — Дашборд.
</div>

<div class="screenshot-placeholder">
    🖼️ Экран входа в систему<br>
    Форма с полями «Логин» и «Пароль» на градиентном фоне
</div>
<div class="screenshot-caption">Рисунок 1 — Страница авторизации</div>

<!-- Раздел 5: Дашборд -->
<h2 id="dashboard">5. Дашборд</h2>

<p><strong>Дашборд</strong> — главная страница системы с основной статистикой и сводной информацией.</p>

<h3>Элементы дашборда:</h3>

<h4>📊 Карточки статистики</h4>
<ul>
    <li><strong>Всего членов</strong> — общее количество записей в базе</li>
    <li><strong>Действительных членов</strong> — активные члены СНТ</li>
    <li><strong>Должников</strong> — количество членов с задолженностью</li>
    <li><strong>Общий долг</strong> — суммарная задолженность по всем членам</li>
    <li><strong>Собрано взносов</strong> — общая сумма поступлений</li>
    <li><strong>Участков</strong> — количество зарегистрированных участков</li>
</ul>

<h4>🥧 Диаграмма «Состав членов СНТ»</h4>
<p>Круговая диаграмма с распределением по статусам:</p>
<ul>
    <li>🟢 Действительные</li>
    <li>🟠 Должники</li>
    <li>⚫ Бывшие</li>
    <li>🔴 Умершие</li>
</ul>

<h4>📋 Таблица «Крупные должники»</h4>
<p>Список должников с наибольшими суммами задолженностей:</p>
<ul>
    <li>ФИО должника</li>
    <li>Телефон для связи</li>
    <li>Сумма долга</li>
    <li>Категория долга (мелкий/средний/крупный)</li>
</ul>

<h4>💳 Таблица «Последние платежи»</h4>
<p>Список последних зарегистрированных платежей:</p>
<ul>
    <li>Дата платежа</li>
    <li>Член СНТ</li>
    <li>Сумма</li>
    <li>Номер квитанции</li>
</ul>

<div class="screenshot-placeholder">
    🖼️ Дашборд системы<br>
    Карточки статистики, диаграмма, таблицы должников и платежей
</div>
<div class="screenshot-caption">Рисунок 2 — Дашборд</div>

<!-- Раздел 6: Члены СНТ -->
<h2 id="members">6. Управление членами СНТ</h2>

<p>Раздел <strong>«Члены СНТ»</strong> предназначен для ведения базы членов товарищества.</p>

<h3>Список членов СНТ</h3>

<p>Таблица со списком членов содержит:</p>
<ul>
    <li><strong>ФИО</strong> — фамилия, имя, отчество</li>
    <li><strong>Телефон</strong> — контактный номер</li>
    <li><strong>Email</strong> — адрес электронной почты</li>
    <li><strong>Участков</strong> — количество принадлежащих участков</li>
    <li><strong>Долг</strong> — текущая задолженность</li>
    <li><strong>Статус</strong> — действительный/должник/бывший/умерший</li>
</ul>

<h3>Фильтры и поиск</h3>

<ul>
    <li><strong>Поиск</strong> — по ФИО и телефону</li>
    <li><strong>Фильтр по статусу</strong> — отбор по статусу члена</li>
</ul>

<h3>Добавление нового члена СНТ</h3>

<div class="step">
    <span class="step-number">1</span>
    <strong>Нажмите кнопку «Добавить»</strong> в верхней части страницы
</div>

<div class="step">
    <span class="step-number">2</span>
    <strong>Заполните поля формы:</strong>
    <ul>
        <li><strong>Фамилия, Имя, Отчество</strong> — обязательные поля</li>
        <li><strong>Дата рождения</strong> — необязательно</li>
        <li><strong>Телефон</strong> — для связи</li>
        <li><strong>Email</strong> — для уведомлений</li>
        <li><strong>Адрес</strong> — почтовый адрес</li>
        <li><strong>Дата вступления</strong> — когда стал членом СНТ</li>
        <li><strong>Статус</strong> — по умолчанию «Действительный»</li>
        <li><strong>Полив на участке</strong> — есть ли полив</li>
    </ul>
</div>

<div class="step">
    <span class="step-number">3</span>
    <strong>Нажмите «Сохранить»</strong>
</div>

<h3>Просмотр карточки члена</h3>

<div class="step">
    <span class="step-number">1</span>
    <strong>Нажмите кнопку «Просмотр»</strong> (иконка глаза) в строке члена
</div>

<div class="step">
    <span class="step-number">2</span>
    <strong>В открывшейся панели</strong> вы увидите:
    <ul>
        <li>Полную информацию о члене</li>
        <li>Список принадлежащих участков</li>
        <li>Сумму задолженности</li>
        <li>Дату вступления в СНТ</li>
    </ul>
</div>

<h3>Редактирование</h3>

<div class="step">
    <span class="step-number">1</span>
    <strong>Нажмите кнопку «Редактировать»</strong> (иконка карандаша)
</div>

<div class="step">
    <span class="step-number">2</span>
    <strong>Измените необходимые поля</strong>
</div>

<div class="step">
    <span class="step-number">3</span>
    <strong>Нажмите «Сохранить»</strong>
</div>

<h3>Удаление</h3>

<div class="warning-box">
    <strong>Внимание!</strong> Удаление члена СНТ необратимо. Рекомендуется менять статус на «Бывший» вместо удаления.
</div>

<div class="step">
    <span class="step-number">1</span>
    <strong>Нажмите кнопку «Удалить»</strong> (красная иконка корзины)
</div>

<div class="step">
    <span class="step-number">2</span>
    <strong>Подтвердите удаление</strong> в диалоговом окне
</div>

<h3>Статусы членов СНТ</h3>

<table>
    <tr>
        <th>Статус</th>
        <th>Описание</th>
        <th>Цвет</th>
    </tr>
    <tr>
        <td>🟢 Действительный</td>
        <td>Активный член СНТ без задолженностей</td>
        <td>Зелёный</td>
    </tr>
    <tr>
        <td>🟠 Должник</td>
        <td>Имеет задолженность по взносам</td>
        <td>Оранжевый</td>
    </tr>
    <tr>
        <td>⚫ Бывший</td>
        <td>Вышел из членов СНТ</td>
        <td>Серый</td>
    </tr>
    <tr>
        <td>🔴 Умерший</td>
        <td>Член СНТ умер</td>
        <td>Красный</td>
    </tr>
</table>

<div class="screenshot-placeholder">
    🖼️ Страница «Члены СНТ»<br>
    Таблица со списком членов, фильтры, кнопки действий
</div>
<div class="screenshot-caption">Рисунок 3 — Управление членами СНТ</div>

<!-- Раздел 7: Участки -->
<h2 id="plots">7. Управление участками</h2>

<p>Раздел <strong>«Участки»</strong> предназначен для учёта земельных участков товарищества.</p>

<h3>Список участков</h3>

<p>Таблица содержит:</p>
<ul>
    <li><strong>Номер</strong> — номер участка</li>
    <li><strong>Аллея</strong> — название аллеи/линии</li>
    <li><strong>Кадастровый №</strong> — кадастровый номер</li>
    <li><strong>Площадь</strong> — размер в сотках</li>
    <li><strong>Владельцы</strong> — ФИО владельцев</li>
    <li><strong>Статус</strong> — активный/неактивный/архив</li>
</ul>

<h3>Добавление участка</h3>

<div class="step">
    <span class="step-number">1</span>
    <strong>Нажмите кнопку «Добавить участок»</strong>
</div>

<div class="step">
    <span class="step-number">2</span>
    <strong>Заполните поля:</strong>
    <ul>
        <li><strong>Номер участка</strong> — обязательное поле</li>
        <li><strong>Аллея</strong> — название улицы/линии</li>
        <li><strong>Кадастровый номер</strong> — по документам</li>
        <li><strong>Площадь</strong> — в сотках (например, 6.50)</li>
        <li><strong>Статус</strong> — по умолчанию «Активный»</li>
        <li><strong>Владельцы</strong> — можно выбрать нескольких членов СНТ</li>
    </ul>
</div>

<div class="step">
    <span class="step-number">3</span>
    <strong>Нажмите «Сохранить»</strong>
</div>

<h3>История владения</h3>

<p>Для каждого участка можно просматривать историю смены владельцев:</p>

<div class="step">
    <span class="step-number">1</span>
    <strong>Нажмите кнопку «История»</strong> (иконка часов) в строке участка
</div>

<div class="step">
    <span class="step-number">2</span>
    <strong>В открывшейся панели</strong> вы увидите:
    <ul>
        <li>Дату перехода права</li>
        <li>ФИО владельца</li>
        <li>Тип перехода (продажа/наследство/дарение)</li>
        <li>Номер документа-основания</li>
        <li>Комментарий</li>
    </ul>
</div>

<h3>Типы перехода права</h3>

<table>
    <tr>
        <th>Тип</th>
        <th>Описание</th>
    </tr>
    <tr>
        <td>📝 Продажа</td>
        <td>Участок продан новому владельцу</td>
    </tr>
    <tr>
        <td>🏛️ Наследование</td>
        <td>Переход по наследству</td>
    </tr>
    <tr>
        <td>🎁 Дарение</td>
        <td>Подарен новому владельцу</td>
    </tr>
    <tr>
        <td>📄 Иное</td>
        <td>Другие основания</td>
    </tr>
</table>

<div class="screenshot-placeholder">
    🖼️ Страница «Участки»<br>
    Таблица участков, история владения
</div>
<div class="screenshot-caption">Рисунок 4 — Управление участками</div>

<!-- Раздел 8: Начисления -->
<h2 id="accruals">8. Начисление взносов</h2>

<p>Раздел <strong>«Начисления»</strong> предназначен для формирования членских взносов.</p>

<h3>Виды взносов</h3>

<ul>
    <li><strong>Членские взносы</strong> — регулярные платежи на содержание СНТ</li>
    <li><strong>Целевые взносы</strong> — на конкретные цели (ремонт, благоустройство)</li>
    <li><strong>Электроэнергия</strong> — оплата электричества</li>
</ul>

<h3>Просмотр начислений</h3>

<p>Таблица начислений содержит:</p>
<ul>
    <li><strong>Член СНТ</strong> — ФИО</li>
    <li><strong>Вид взноса</strong> — тип начисления</li>
    <li><strong>Год</strong> — период начисления</li>
    <li><strong>Сумма</strong> — полная сумма</li>
    <li><strong>Оплачено</strong> — внесённая сумма</li>
    <li><strong>Остаток</strong> — задолженность</li>
    <li><strong>Статус</strong> — оплачено/не оплачено</li>
    <li><strong>Срок оплаты</strong> — дедлайн</li>
</ul>

<h3>Массовое начисление взносов</h3>

<div class="info-box">
    <strong>Совет!</strong> Используйте массовое начисление для быстрого формирования взносов всем членам СНТ.
</div>

<div class="step">
    <span class="step-number">1</span>
    <strong>Нажмите кнопку «Массовое начисление»</strong>
</div>

<div class="step">
    <span class="step-number">2</span>
    <strong>Заполните параметры:</strong>
    <ul>
        <li><strong>Вид взноса</strong> — выберите тип</li>
        <li><strong>Год</strong> — период начисления</li>
        <li><strong>Ставка (₽/сотка)</strong> — сумма за 1 сотку</li>
        <li><strong>Срок оплаты</strong> — дата дедлайна</li>
    </ul>
</div>

<div class="step">
    <span class="step-number">3</span>
    <strong>Нажмите «Сохранить»</strong>
</div>

<p>Система автоматически рассчитает сумму для каждого члена СНТ на основе площади его участков.</p>

<h3>Индивидуальное начисление</h3>

<div class="step">
    <span class="step-number">1</span>
    <strong>Нажмите кнопку «Добавить»</strong>
</div>

<div class="step">
    <span class="step-number">2</span>
    <strong>Заполните поля:</strong>
    <ul>
        <li><strong>Член СНТ</strong> — выберите из списка</li>
        <li><strong>Вид взноса</strong> — тип</li>
        <li><strong>Год</strong> — период</li>
        <li><strong>Сумма</strong> — вручную введите сумму</li>
        <li><strong>Срок оплаты</strong> — необязательно</li>
    </ul>
</div>

<div class="step">
    <span class="step-number">3</span>
    <strong>Нажмите «Сохранить»</strong>
</div>

<h3>Фильтры</h3>

<ul>
    <li><strong>Год</strong> — выбор периода отображения</li>
    <li><strong>Член СНТ</strong> — фильтр по конкретному человеку</li>
</ul>

<div class="screenshot-placeholder">
    🖼️ Страница «Начисления»<br>
    Таблица начислений, форма массового начисления
</div>
<div class="screenshot-caption">Рисунок 5 — Начисление взносов</div>

<!-- Раздел 9: Платежи -->
<h2 id="payments">9. Регистрация платежей</h2>

<p>Раздел <strong>«Платежи»</strong> предназначен для учёта поступлений от членов СНТ.</p>

<h3>Список платежей</h3>

<p>Таблица содержит:</p>
<ul>
    <li><strong>Дата</strong> — когда внесён платёж</li>
    <li><strong>Член СНТ</strong> — кто оплатил</li>
    <li><strong>Сумма</strong> — размер платежа</li>
    <li><strong>Способ</strong> — наличные/карта/перевод</li>
    <li><strong>Квитанция</strong> — номер документа</li>
</ul>

<h3>Регистрация платежа</h3>

<div class="step">
    <span class="step-number">1</span>
    <strong>Нажмите кнопку «Зарегистрировать платёж»</strong>
</div>

<div class="step">
    <span class="step-number">2</span>
    <strong>Выберите члена СНТ</strong> — после выбора загрузятся его начисления
</div>

<div class="step">
    <span class="step-number">3</span>
    <strong>Заполните поля:</strong>
    <ul>
        <li><strong>Дата платежа</strong> — когда внесены деньги</li>
        <li><strong>Способ оплаты</strong> — наличные/карта/перевод</li>
        <li><strong>Распределение по начислениям</strong> — на что идёт платёж:
            <ul>
                <li>Выберите начисление из списка</li>
                <li>Укажите сумму распределения</li>
                <li>Можно добавить несколько распределений</li>
            </ul>
        </li>
        <li><strong>Комментарий</strong> — необязательно</li>
    </ul>
</div>

<div class="step">
    <span class="step-number">4</span>
    <strong>Нажмите «Сохранить»</strong>
</div>

<div class="info-box">
    <strong>Важно!</strong> Сумма платежа автоматически рассчитывается как сумма всех распределений.
</div>

<h3>Печать квитанции</h3>

<div class="step">
    <span class="step-number">1</span>
    <strong>Найдите платёж в таблице</strong>
</div>

<div class="step">
    <span class="step-number">2</span>
    <strong>Нажмите кнопку «Печать»</strong> (иконка принтера) в строке платежа
</div>

<div class="step">
    <span class="step-number">3</span>
    <strong>Квитанция откроется в новой вкладке</strong> в формате PDF
</div>

<div class="step">
    <span class="step-number">4</span>
    <strong>Распечатайте или сохраните</strong> квитанцию
</div>

<h3>Массовая печать</h3>

<div class="step">
    <span class="step-number">1</span>
    <strong>Отметьте галочкой</strong> нужные платежи в таблице
</div>

<div class="step">
    <span class="step-number">2</span>
    <strong>Нажмите кнопку «Печать (оригинал + копия)»</strong>
</div>

<div class="step">
    <span class="step-number">3</span>
    <strong>PDF со всеми квитанциями откроется для печати</strong>
</div>

<h3>Способы оплаты</h3>

<table>
    <tr>
        <th>Способ</th>
        <th>Описание</th>
    </tr>
    <tr>
        <td>💵 Наличные</td>
        <td>Оплата наличными через кассу</td>
    </tr>
    <tr>
        <td>💳 Карта</td>
        <td>Оплата банковской картой</td>
    </tr>
    <tr>
        <td>🏦 Банковский перевод</td>
        <td>Перевод счёта через банк</td>
    </tr>
</table>

<div class="screenshot-placeholder">
    🖼️ Страница «Платежи»<br>
    Таблица платежей, форма регистрации, печать квитанции
</div>
<div class="screenshot-caption">Рисунок 6 — Регистрация платежей</div>

<!-- Раздел 10: Отчёты -->
<h2 id="reports">10. Отчёты</h2>

<p>Раздел <strong>«Отчёты»</strong> содержит аналитические отчёты по деятельности СНТ.</p>

<h3>Отчёт по взносам</h3>

<p>Показывает состояние расчётов по взносам за выбранный год:</p>

<h4>Сводные показатели:</h4>
<ul>
    <li><strong>Начислено</strong> — общая сумма всех начислений</li>
    <li><strong>Оплачено</strong> — сумма поступлений</li>
    <li><strong>Остаток долга</strong> — непогашенная задолженность</li>
</ul>

<h4>Таблица по видам взносов:</h4>
<ul>
    <li>Вид взноса (членские/целевые/электроэнергия)</li>
    <li>Начислено по виду</li>
    <li>Оплачено по виду</li>
    <li>Остаток</li>
    <li>Процент оплаты</li>
</ul>

<h3>Отчёт по должникам</h3>

<p>Список всех должников СНТ с детализацией:</p>
<ul>
    <li><strong>ФИО</strong> — должника</li>
    <li><strong>Телефон</strong> — для связи</li>
    <li><strong>Участков</strong> — количество</li>
    <li><strong>Долг</strong> — сумма задолженности</li>
    <li><strong>Категория</strong> — размер долга:
        <ul>
            <li>🟠 Мелкий (&lt; 1 000 ₽)</li>
            <li>🔴 Средний (1 000 — 5 000 ₽)</li>
            <li>🔴 Крупный (&gt; 5 000 ₽)</li>
        </ul>
    </li>
</ul>

<h4>Сводка по должникам:</h4>
<ul>
    <li><strong>Всего должников</strong> — количество</li>
    <li><strong>Общая сумма долга</strong> — все долги</li>
    <li><strong>Крупные должники</strong> — с долгом &gt; 5 000 ₽</li>
</ul>

<div class="screenshot-placeholder">
    🖼️ Страница «Отчёты»<br>
    Отчёт по взносам, отчёт по должникам
</div>
<div class="screenshot-caption">Рисунок 7 — Отчёты</div>

<!-- Раздел 11: FAQ -->
<h2 id="faq">11. Часто задаваемые вопросы</h2>

<h3>❓ Как сменить пароль?</h3>
<p>В текущей версии смена пароля осуществляется через администратора системы. Обратитесь к пользователю с ролью <code>admin</code>.</p>

<h3>❓ Что делать, если забыл пароль?</h3>
<p>Обратитесь к администратору для сброса пароля. Учётная запись по умолчанию: <code>admin / admin123</code></p>

<h3>❓ Как исправить ошибку в начислении?</h3>
<p>Удалите ошибочное начисление и создайте новое с правильными данными. Для массовых исправлений обратитесь к администратору.</p>

<h3>❓ Можно ли изменить сумму платежа?</h3>
<p>Изменение суммы платежа невозможно после сохранения. Удалите платёж и создайте новый с корректной суммой.</p>

<h3>❓ Как добавить историю владения участком?</h3>
<p>При редактировании участка выберите новых владельцев в поле «Владельцы». История владения ведётся автоматически.</p>

<h3>❓ Где найти сгенерированные квитанции?</h3>
<p>Квитанции хранятся в папке <code>uploads/receipts/</code> на сервере. Также можно распечатать их из раздела «Платежи».</p>

<h3>❓ Как сделать резервную копию данных?</h3>
<p>Используйте скрипт резервного копирования <code>backup.sh</code> (настраивается при установке). Рекомендуется ежедневное резервное копирование.</p>

<h3>❓ Система работает медленно. Что делать?</h3>
<p>Проверьте:</p>
<ul>
    <li>Доступность сервера базы данных</li>
    <li>Свободное место на диске</li>
    <li>Логи ошибок: <code>docker compose logs backend</code></li>
</ul>

<!-- Раздел 12: Контакты -->
<h2 id="contacts">12. Контакты</h2>

<div class="contact-info">
    <h3>🏡 СНТ «Монолит»</h3>
    <p><strong>Адрес:</strong> 644043 Россия, г. Омск, ул. Партизанская 12</p>
    <p><strong>Председатель:</strong> Пегасин Александр Александрович</p>
    <p><strong>Телефон:</strong> 8 950 339 6939</p>
    <p><strong>Email:</strong> snt-monolit@yandex.ru</p>
</div>

<h3>Техническая поддержка</h3>

<p>По вопросам работы системы обращайтесь к администратору СНТ.</p>

<div class="info-box">
    <strong>Время работы правления:</strong><br>
    Пн–Пт: 9:00 — 18:00<br>
    Сб: 10:00 — 14:00<br>
    Вс: выходной
</div>

<!-- Футер -->
<div style="margin-top: 60px; padding-top: 20px; border-top: 1px solid #d9d9d9; text-align: center; color: #999; font-size: 9pt;">
    <p>АИС «СНТ-Управление» © {year} СНТ «Монолит»</p>
    <p>Версия документа: 1.0 | Дата создания: {date}</p>
</div>
"""


def generate_pdf():
    """Генерация PDF-документа руководства пользователя."""
    
    # Подстановка даты
    today = datetime.now().strftime("%d.%m.%Y")
    year = datetime.now().year
    
    content = CONTENT.format(date=today, year=year)
    full_html = HTML_TEMPLATE.format(content=content)
    
    # Создание PDF
    print("Генерация PDF-документа...")
    
    # Настройка шрифтов
    font_config = FontConfiguration()
    
    css = CSS(string="""
        @font-face {
            font-family: "Segoe UI";
            src: local("Segoe UI"), local("Arial");
        }
    """, font_config=font_config)
    
    # Генерация PDF
    html = HTML(string=full_html, base_url=OUTPUT_DIR)
    pdf_path = os.path.join(OUTPUT_DIR, "user_manual.pdf")
    
    html.write_pdf(
        pdf_path,
        stylesheets=[css],
        font_config=font_config,
    )
    
    print(f"✓ PDF-документ создан: {pdf_path}")
    print(f"  Размер файла: {os.path.getsize(pdf_path) / 1024 / 1024:.2f} МБ")
    
    return pdf_path


if __name__ == "__main__":
    generate_pdf()
